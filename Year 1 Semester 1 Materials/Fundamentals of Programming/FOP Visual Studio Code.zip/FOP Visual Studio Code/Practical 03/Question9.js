var money
notesOfMoney = [1000.00,100.00,50.00,10.00,5.00,2.00,1.00]
var readlineSync = require('readline-sync');
money = readlineSync.question('Enter amount($): ')

for(note of notesOfMoney) {
    var numberofNote = parseInt(money/note)
    money = money - (note*numberofNote)
    console.log(numberofNote);
}