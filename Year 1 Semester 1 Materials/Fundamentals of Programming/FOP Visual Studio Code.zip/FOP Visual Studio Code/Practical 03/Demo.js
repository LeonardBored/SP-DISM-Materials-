var firstArr = ['one', 'two', 'three'];

var secondArr = firstArr;

secondArr[1] = 2;

console.log( firstArr);

console.log( secondArr );