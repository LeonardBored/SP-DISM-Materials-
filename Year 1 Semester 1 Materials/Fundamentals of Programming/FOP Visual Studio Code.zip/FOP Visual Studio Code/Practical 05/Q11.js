var base1, lastBase, columnList = [] , columnTitle = "row \t"; 
var readline = require('readline-sync')
base1 = readline.questionInt("Enter 1st Base: ")
lastBase = readline.questionInt("Enter last base: ")

for (base1 ; base1 <= lastBase ; base1 ++) {
    columnList.push(base1)
}

for (i = 0; i <= lastBase.length -1 ; i++) {
    columnTitle += columnList[i] + "\t"
}
console.log(columnTitle)

for (i = 1 ; i <= 25 ; i++) {
    var rowString = i + "\t"
    for (j = 0 ; j < columnList.length ; j++) {
        rowString += i * columnList[j] + "\t"
    }
    console.log(rowString)
}