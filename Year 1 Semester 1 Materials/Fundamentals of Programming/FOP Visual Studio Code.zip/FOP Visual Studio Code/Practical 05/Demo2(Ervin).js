var input = require("readline-sync")
var x = input.question('Enter 1st number: ')
var y =  input.question('Enter 2nd number: ')
var string = ''

for (var i = parseInt(x) + 1; i < y; i++) {
    if (i % 2 == 1) {
        string += i + " "
    }
}

console.log(`Odd numbers betweeen ${x} and ${y}: `)
console.log(string)