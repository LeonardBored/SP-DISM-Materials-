var readline = require("readline-sync")
var firstBase= readline.questionInt("Enter first base value: ")
var lastBase = readline.questionInt("Enter last base value: ")
var columnList = []
var columnTitle = "row \t"

for (firstBase; firstBase <= lastBase; firstBase++) {
   columnList.push(firstBase)
}

for (var i = 0; i <= columnList.length -1 ;i++) { 
   columnTitle += columnList[i] + "\t"
}
console.log('Column\n${columnTitle}\nrow \n')

for (i=1; i<=25; i++) {
   var rowString = i + "\t"
   for (j=0; j < columnList.length; j++) {
      rowString += columnList[j]*i + "\t"
   }
   console.log(rowString)
}