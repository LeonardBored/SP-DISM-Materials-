var peak; 
var readline = require('readline-sync')
peak = readline.questionInt("Enter a peak not larger than 10: ")
if (peak > 10) {
    peak = 3
}

for (var count1 = 0 ; count1 <= peak ; count1++) {
    s = ""
} for (var count2 = 1 ; count2 <= count1 ; count2 ++) {
    s += "#"
    console.log(s)
} 

for (var count3 = peak - 1  ; count3 >= 0 ; count3--) {
    s = ""
    for (var count4 = count3 ; count4 >= 0; count4 --) {
        s += "#"
    }
    console.log(s)
}