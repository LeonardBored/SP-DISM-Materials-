var num, divisble, outOfRange;
var readline = require("readline-sync")
do {
    num = readline.question("Enter any number or (0) to quit: ")
    if (num < 50 && num != 0|| num > 100) {
        console.log("Error: Out of range!")
        outOfRange = true

    } else if (num == 0) {
            break;

    } if (num % 3 == 0 && num % 5 != 0) {                    
            divisible = true 
    }  
    else {
         divisible = false 
    }
    console.log(num + " is divisible by 3 but not 5? " + divisible)
            
} while(num != 0 || outOfRange == true)
    console.log("Program Terminated…") 

