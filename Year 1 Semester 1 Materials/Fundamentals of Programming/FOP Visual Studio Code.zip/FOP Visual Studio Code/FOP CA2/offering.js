// Each class for each category//

const { keyInYNStrict } = require("readline-sync");   // Reads input key from keyboard. keyIn === 'Enter' is enter on keyboard//

const {orderCart,pricePerOrder} = require("./orderCart")

// Function used to display error in input //
function errorMessage() {                             
    if (input != 0) {                                 // Ensure that input == 0 won't print invalid //
    console.log("\x1b[31m%s\x1b[0m","Invalid Number! Please re-enter a valid number.") 
    }
}

// Function used to check whether user presses only Y or N on keyboard after adding an item to cart //
function pressYN() {                                
    input = readline.keyInYNStrict("\nPress Y or N to continue...\n")
    input = 0    // Makes user go all the way back to welcome page //
}

// This function checks for valid quantity entered and calculates price based off it. It also prints the price //
function checkQuantity(obj,name,price,option) {   
    while(input != 0) {
        input = readline.questionInt("\nEnter order quantity. Press 0 for Cancel Selection\n>>> ") // input can't be obj.QTY as if - is entered, it will not go back to start //
        obj.QTY = parseInt(input)      // Sets obj.QTY as input // 
        if (obj.QTY > 0) {
            console.log("\n==================================================================")                                     // Local var str then does the adding of text //
            console.log("\x1b[32m%s\x1b[0m","Added to Cart - QTY: " + obj.QTY + " X " + name + option + "- $ " + price.toFixed(2))  // .toFixed is used so price can be in 2 decimal place //
            console.log("==================================================================")
            pricePerOrder.push(obj.QTY * price)                                                                                     // Pushes total price of order into pricePerOrder Array //
            orderCart.push("QTY: " + obj.QTY + " X " + name + option + "- $ " + price.toFixed(2))                                   // Pushes the order into orderCart array //
            pressYN()
        } else {
            errorMessage() // for when input is invalid //
        }
    } 
}

// This function does the choosing of options from selection array containing different numbers of options //
function optionCheck(optionArr,ItemName) {   
    while(input != 0) {
        var str = "Choose an option for " + ItemName          // Top of str //
        for (let i = 0; i < optionArr.length ; i++){          // Loops through array of options in a selection array //
            str += "\n\t\t\t[" + (i+1) + "] " + optionArr[i]  // stores all available options in a string //
        } 
        input = readline.questionInt(str + "\n\t\t\t[0] Cancel Selection\n>>> ")
        if (input <= optionArr.length && input > 0) {       // If input is valid within the range of the all indexs of the array //
            return "|" + optionArr[input-1] + "|"           // Returns selected option //
        }
    }
}

// This function loops through different selections in the selection array and goes into the optionCheck function when choosing an option from a selection //
function optionChoose(ChosenItemObj,ChosenItemOptionsArr) {  // options parameter will take in an array //
    var selectedOption = " "                                 // Empty string first //
    if (ChosenItemOptionsArr != null) {                      // ensures that options is not null. If null, it will skip and not ask for any options //
        for (let i = 0 ; i < ChosenItemOptionsArr.length ; i ++) { 
            selectedOption += optionCheck(ChosenItemOptionsArr[i],ChosenItemObj.name) // loops through the array and ask for each selection //
        } 
    }                                      
    checkQuantity(ChosenItemObj,ChosenItemObj.name,ChosenItemObj.price,selectedOption)     // Asks for quantity and pushes the information by pushing in arrays over to orderCart.js //
}

// This function helps to declare objects in the menu //
function declareObj(MenuItemObj,nameOfObj,priceOfObj) {
    var MenuItemObj = new Object()  // obj is made an object //
    MenuItemObj.name = nameOfObj    // Properties such as name,price and options are assigned to it //
    MenuItemObj.price = priceOfObj
    return MenuItemObj              // Returns the whole object declared //
}

// Noodles Category //

// declareObj(Object name, object.name , object.price, object.options) this function helps to declare properties of objects //
var beeHoonObj = declareObj(beeHoonObj,"Bee Hoon",3.5) 

var friedKwayTeowObj = declareObj(friedKwayTeowObj,"Fried Kway Teow",4)
friedKwayTeowObj.option = [["Dry","Soup"],["Spicy","No-Spicy"]] // selections is in an array with a bigger array //

var ramenObj = declareObj(ramenObj,"Ramen",6)
ramenObj.option = [["Toppings: Spring Onion","Toppings: None"],["Add Egg","No Egg"]] // To add more selections/options in a option select, add into exisiting array // 

var roastedDuckNoodlesObj = declareObj(roastedDuckNoodlesObj,"Roasted Duck Noodles",3)
roastedDuckNoodlesObj.option = [["Spicy","No-Spicy"],["Soup","Dry"]]   // To add more than one selection, just add another array into the big array //

var shoyuSobaObj = declareObj(shoyuSobaObj,"Shoy Soba",5.5)
shoyuSobaObj.option = [["Hot","Cold"]]


var noodlesArr = [beeHoonObj,friedKwayTeowObj,ramenObj,roastedDuckNoodlesObj,shoyuSobaObj] // Array containing all objects //
var noodlesObj = {category: "NOODLES", Array : noodlesArr} // Noodles Object that has a category name and array //
// End of noodles category //

// Rice Category //

var friedRiceObj = declareObj(friedRiceObj,"Fried Rice",4.5)
friedRiceObj.option = [["More Rice","Normal Rice"], ["Add More Meat","Normal Meat"], ["Add egg","Normal Egg","No Egg"]] // 3 selections in total with last selection offering up to 3 different options //

var chickenRiceObj = declareObj(chickenRiceObj,"Chicken Rice",3)
chickenRiceObj.option = [["More Chicken","Normal Chicken"],["Add Egg","No Egg"],["Add Soup","No Soup"]]

var curryRiceObj = declareObj(curryRiceObj,"Curry Rice",5)
curryRiceObj.option = [["Meat: Chicken","Meat: Fish"],["More Rice","Normal Rice"]]

var unagiRiceObj = declareObj(unagiRiceObj,"Unagi Rice",7)

var riceArr = [friedRiceObj,chickenRiceObj,curryRiceObj,unagiRiceObj] // Array containing all objects //
var riceObj = {category: "RICE", Array: riceArr}
// End of Rice Category //

// Drinks Category //

var waterObj = declareObj(waterObj,"Water",0.5)
waterObj.option = [["Hot","Cold"]]

var cokeObj = declareObj(cokeObj,"Coke",1.5)

var pepsiObj = declareObj(pepsiObj,"Pepsi",1.5)

var spriteObj = declareObj(spriteObj,"Sprite",1.5)

var lemonTeaObj = declareObj(lemonTeaObj,"Lemon Tea",2)
lemonTeaObj.option = [["Hot","Cold"]]

var drinksArr = [waterObj,cokeObj,pepsiObj,spriteObj,lemonTeaObj] // Array containing all objects //
var drinksObj = {category: "DRINKS", Array: drinksArr}
// End of Drinks Category //

// Snacks Category //

var iceCreamObj = declareObj(iceCreamObj,"Ice Cream",2,)
iceCreamObj.option = [["Vanilla Flavour","Chocolate Flavour"]]

var iceKacangObj = declareObj(iceKacangObj,"Ice Kacang",1.5)

var butterCookiesObj = declareObj(butterCookiesObj,"Butter Cookies",2)

var fruitTartObj = declareObj(fruitTartObj,"Fruit Tart",3.5)
fruitTartObj.option = [["Strawberry Flavour","Blueberry Flavour"]]

var puddingObj = declareObj(puddingObj,"Pudding",2)
puddingObj.option = [["Mango Flavour","Lemon Flavour"]]

var snacksArr = [iceCreamObj,iceKacangObj,butterCookiesObj,fruitTartObj,puddingObj] // Array containing all objects //
var snacksObj = {category: "SNACKS", Array: snacksArr}
// End of Snacks Category // 

// Soup Category //
 
var mushroomSoupObj = declareObj(mushroomSoupObj,"Mushroom Soup",2)  // No customization for soup category in terms of options // 

var misoSoupObj = declareObj(misoSoupObj,"Miso Soup",1.5)

var sharkFinSoupObj = declareObj(sharkFinSoupObj,"Shark Fin Soup",20)

var soupsArr = [mushroomSoupObj,misoSoupObj,sharkFinSoupObj] // Array containing all objects //
var soupsObj = {category: "SOUPS", Array: soupsArr}
// End of Soup Category //

// Array of objects : Categories //

var categories = [noodlesObj,riceObj,drinksObj,snacksObj,soupsObj]  // Contains all arrays of objects of each category //


// end of array of objects //

// class OrderItem that is made everytime there is a new order //
class OrderItem {  
    selectChoice(catergorySelected,dishSelected) {                 // Gets the category selected + dish selected from user in main //
        var chosenItem = catergorySelected[dishSelected]           // Sets chosen item as the dish selected //
        optionChoose(chosenItem,chosenItem.option)                 // Goes through option choose function to choose options available in that dish //
    }
}

module.exports = [OrderItem,pressYN,errorMessage,categories]; // export functions + arrays + class OrderItem //
