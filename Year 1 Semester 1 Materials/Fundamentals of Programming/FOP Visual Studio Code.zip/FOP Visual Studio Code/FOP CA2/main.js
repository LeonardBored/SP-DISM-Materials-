
var [OrderItem,pressYN,errorMessage,categories] = require('./offering')  // Importing of arrays, functions from offering and OrderItem Class //

const {viewOrders,removeOrder,receipt,removeCart,discount,luckyDraw} = require("./orderCart") // Importing of cart options functions from cartOrder //                                                           

var discountClaimed = 0                                    // Checks whether discount has been claimed before and ensure that user cannot enter again if claimed before //
var luckyDrawClaimed = 0                                   // Checks whether lucky draw has been claimed before //

console.log('\x1b[33m%s\x1b[0m',`\n\n███╗░░██╗██╗░█████╗░███████╗███╗░░░███╗███████╗░█████╗░██╗░░░░░░░░░░░░░░░░░░░░░░░██╗░░ 
████╗░██║██║██╔══██╗██╔════╝████╗░████║██╔════╝██╔══██╗██║░░░░░░░░░░░░░░░░░░░░░░░╚██╗░
██╔██╗██║██║██║░░╚═╝█████╗░░██╔████╔██║█████╗░░███████║██║░░░░░█████╗█████╗█████╗░╚██╗
██║╚████║██║██║░░██╗██╔══╝░░██║╚██╔╝██║██╔══╝░░██╔══██║██║░░░░░╚════╝╚════╝╚════╝░██╔╝
██║░╚███║██║╚█████╔╝███████╗██║░╚═╝░██║███████╗██║░░██║███████╗░░░░░░░░░░░░░░░░░░██╔╝░
╚═╝░░╚══╝╚═╝░╚════╝░╚══════╝╚═╝░░░░░╚═╝╚══════╝╚═╝░░╚═╝╚══════╝░░░░░░░░░░░░░░░░░░╚═╝░░`)

console.log('\x1b[35m%s\x1b[0m',`██████╗░███████╗░██████╗████████╗░█████╗░██╗░░░██╗██████╗░░█████╗░███╗░░██╗████████╗
██╔══██╗██╔════╝██╔════╝╚══██╔══╝██╔══██╗██║░░░██║██╔══██╗██╔══██╗████╗░██║╚══██╔══╝
██████╔╝█████╗░░╚█████╗░░░░██║░░░███████║██║░░░██║██████╔╝███████║██╔██╗██║░░░██║░░░
██╔══██╗██╔══╝░░░╚═══██╗░░░██║░░░██╔══██║██║░░░██║██╔══██╗██╔══██║██║╚████║░░░██║░░░
██║░░██║███████╗██████╔╝░░░██║░░░██║░░██║╚██████╔╝██║░░██║██║░░██║██║░╚███║░░░██║░░░
╚═╝░░╚═╝╚══════╝╚═════╝░░░░╚═╝░░░╚═╝░░╚═╝░╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚══╝░░░╚═╝░░░`)   
//  %s is where in the string (the second argument) gets injected. \x1b[0m resets terminal color //

// This function gets input from the user on their selected category in all the available categories //
function categorySelection(categories) {
    while(input != 0) {                           // Only enter loop when input != 0 //
        var str = "\tSelect Category\n"           // Local var str then does the concatanation of text //
        for(i=0; i < categories.length ; i++) {   // Loops through all categories in categories Array and stroes them in a string  //
            str +=("\t[" + (i+1) + "] " + categories[i].category + "\n")  // String concatanation //
        }
        input = readline.questionInt(str+ "\t[0] Cancel Selection\n>>> ") // Question //
        if (input <= categories.length && input > 0) {                  // If input is within the range of index in the category Array //
            var type = categories[input-1].category.slice(0,2)          // Sets string being printed for each dish during selection by taking first 2 characters of catergory name //
            dishSelection(categories[input-1],type)                     // Dish selection function with selected category (catergory[input-1]) and type as argument //
        }
        errorMessage()
    }
}

// This function gets input from the user on their selected dish from all available dishes // 
function dishSelection(selectedCategory,type) {
    while(input != 0) {                         // Only enter loop when input != 0 //
        var str = "\n\t\tSelect Dishes from " + selectedCategory.category + "\n"   // Local var str then does the concatanation of text  + the name of the category //
        for (let i = 0; i < selectedCategory.Array.length ; i++) {                 // Loop through the whole selected category Arr's items //
            str += "\t\t[" +  + (i+1) + "] " + type + 0 + (1 + i) +": $" + selectedCategory.Array[i].price.toFixed(2) + " - " + selectedCategory.Array[i].name + "\n" // Prints out all object's properties in their respective category //
        }
        input = readline.questionInt(str + "\t\t[0] Cancel Selection\n>>> ")       // Question //
        if (input <= selectedCategory.Array.length && input > 0) {                 // If input is valid within the range of the all indexs of the array //
                new OrderItem().selectChoice(selectedCategory.Array,input-1)       // Makes a new OrderItem with arguments (selected category array,index of chosen dish) //
        } 
        errorMessage()
    }
}

while(true) {                                              // Main logic in programme //
    input = null                                           // Resets input whenever at start of programme // 
    readline = require('readline-sync')                    // Makes readline-sync a global variable //
    input = readline.questionInt("\nWelcome to NiceMeal Restaurant\n1. View Menu\n2. View Cart\n0. Quit\n>>> ")
        if (input == 0) {                                  //Confirming user whether to quit programme//
            var confirmQuit                                // local confirmQuit variable that is not global to the rest of the programme //
            do {                              
                confirmQuit = readline.questionInt("\n\nAre you sure?\n1. No\n2. Yes\n>>> ")
                if (confirmQuit != 1 && confirmQuit != 2) {
                    console.log("\x1b[31m%s\x1b[0m","Invalid Number! Please re-enter a valid number : 1.(Cancel) or 0.(Quit)") // error messeage when input =/= 1 or 2
                }                                          
            } while (confirmQuit != 1 && confirmQuit != 2) // do while loop that loops whenever input =/= 1 or 2
            if (confirmQuit == 2) {                        // when confirmQuit is 2, this will break out of programme, thus terminating it//
                console.log("\x1b[32m%s\x1b[0m","\nThank you, goodbye!")
                break;
            } 
        }
    switch(input) {    // Switch case between 1. view menu and 2. view cart //
        case 1 : 
            categorySelection(categories) // To choose categories and subsequent dishes //
            break;
        case 2 :
            while(input != 0) {
                viewOrders()
                if(input != 0) {           // Ensures that input != 0 to continue // 
                    input = readline.questionInt("\nEnter Cart Option\n1. Send Order\n2. Remove Item\n3. Redeem a Discount Code\n4. Empty Cart\n5. Lucky Draw!\n0. Back to Main\n>>> ")
                    switch(input) {
                        case 1:             // send order using text file//
                            receipt()       // Appends receipt onto text file. Function imported from orderCart.js//
                            console.log("\x1b[32m%s\x1b[0m","\nOrder Sent!")
                            pressYN()       // Press y/n to continue ...//
                            break;
                        case 2: 
                            removeOrder()   // Removes order item function from orderCart.js//
                            break;
                        case 3:
                            if (discountClaimed == 0) { // Ensures that discountClaimed == 0 //
                                discount()              // Discount function exported from orderCart.js //
                                discountClaimed++       // Increments such that only can be claimed once //
                            } else {
                                console.log("\x1b[31m%s\x1b[0m","Discount already Redeemed!")
                            }
                            break;
                        case 4:
                            removeCart()                                       // Remove whole cart //
                            console.log("\x1b[32m%s\x1b[0m","\nCart Emptied!") // Prints out cart emptied to let user to know //
                            break;
                        case 5: 
                            if (luckyDrawClaimed == 0) { // Ensures that luckyDrawClaimed == 0 //
                            luckyDraw()                  // Goes to luckyDraw function in orderCart //
                            luckyDrawClaimed++           // Increments the luckyDrawClaimed counter to ensure user cannot go through this again //
                            } else {
                                console.log("\x1b[31m%s\x1b[0m","You have tried the maximum attempts for the Lucky Draw today. Please try tomorrow")
                            }
                            break; // to ensure that it breaks after case 2 and not go to default //
                        default :
                            errorMessage()
                        }
                }
            } break; // to ensure that it breaks after case 2 and not go to default //
        default : 
        errorMessage() // end of case of main page 
    }
}
