var readline = require('readline-sync')
var arr = []

do {
    var num1 = readline.questionInt("Enter first Number: ")
    var num2 = readline.questionInt("Enter Second Number: ")
    var x = readline.questionInt("Enter a multiple: ")
    if (num1 > num2) {
        console.log("Number 1 should be smaller or equal to num2. Please re-enter\nthe numbers again")
    }
} while(num1 > num2)

allMultiple(num1, num2, x)

function allMultiple(num1 , num2, x) {
    for (var i = num1 ; i <= num2 ; i++) {
        if (i % x ==0) {
            arr.push(i)
        }
    }
    console.log(arr)
}