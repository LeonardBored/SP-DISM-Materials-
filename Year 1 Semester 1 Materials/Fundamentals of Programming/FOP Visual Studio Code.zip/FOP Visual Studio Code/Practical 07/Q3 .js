var year

function isLeapYear(year) {
    if (year % 4 == 0 && year % 100 != 0) {
        return true
    } else {
        return false
    }
}

var readline = require('readline-sync')
year = readline.question("Enter a year: ")
console.log(year + " is a leap year? " + isLeapYear(year))