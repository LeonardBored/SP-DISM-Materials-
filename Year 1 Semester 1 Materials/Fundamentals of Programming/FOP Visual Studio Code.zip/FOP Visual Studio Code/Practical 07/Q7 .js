var input = require("readline-sync");
var pat = choosePattern();
var num = readInput();

switch (pat) {
    case 1: 
            printPattern1(num)
            break;

    case 2: 
            printPattern2(num)
            break;

    case 3: 
            printPattern3(num)
            break;

    case 4: 
            break;

    default: console.log("error")
}

function readInput() { 
    var rows
    rows = input.questionInt("Enter the number of rows : ")
    return rows
}

function choosePattern() { 
    var pattern
    pattern = input.questionInt(" 1. Print pattern 1 \n 2. Print pattern 2 \n 3. Print pattern 3 \n 4. Exit \n")
    return pattern

}

function printPattern1(n) { 

    for (i = 1; i <= n; i++ ) {
        var s  = ""
        for (j = 1; j <= n; j++) {
            s += i + "\t"
        }
        console.log(s)
    }
}

function printPattern2(n) { 
    for (i=1; i <= n; i++) {
        var s = ""
        for (j=1; j<=n; j++) {
            s += j + "\t"
        }
        console.log(s)
    }
}

function printPattern3(n) { 
    for (i=1; i<=n; i++) {
        var s = ""
        for (j=1; j<=n; j++) {
            s+= i*j + "\t"
        }
        console.log(s)
    }
}

