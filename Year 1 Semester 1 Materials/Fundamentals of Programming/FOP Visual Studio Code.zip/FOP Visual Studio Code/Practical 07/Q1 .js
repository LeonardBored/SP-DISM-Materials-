var num, counter, product;
var readline = require('readline-sync')
num = readline.questionInt("Please enter a number: ")
function printTable() {
for(counter = 1; counter <= 12 ; counter++ ) {
    product = counter * num
    console.log(counter + " x " + num + " = " + product)
    }
}

printTable()