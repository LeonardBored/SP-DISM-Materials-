var rank = 0 , money;

function getInput() {
var readline = require('readline-sync');
rank = readline.questionInt('Please enter your rank: ')
return rank;
}

function printPrize(rank) {
    switch(rank){
        case 1: 
        money = 1000
        break;
        
        case 2: 
        money = 800
        break;

        case 3: 
        money = 700
        break;

        case 4: 
        money = 300
        break;

        case 5: 
        money = 300
        break;

        default: 
        money = 20
        }
    console.log('Your prize money is $' + money)
}

rank = getInput()
printPrize(rank)