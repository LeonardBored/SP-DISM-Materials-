var firstBase,lastBase

var rowString = "row \t"

var readline = require('readline-sync')
firstBase = readline.question("Enter first base: ")
lastBase = readline.question("Enter last base: ")

console.log("Column")

for(var k = firstBase ; k <= lastBase ; k ++) {
    rowString += k + "\t"
}

console.log(rowString + "\n")

for(var i = 1; i <= 25; i ++) {
    s = i + "\t"
    for (var j = firstBase; j <= lastBase; j++) {
        s += i*j + "\t"
    }
    console.log(s)
}
