var readline = require('readline-sync');
var name = readline.question("What's your name? ");
console.log("Hello " + name + ",\nIt is a good day today");
