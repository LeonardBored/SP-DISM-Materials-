
console.log("Welcome to Fundamentals of Programming");
console.log("This is my first program!");
