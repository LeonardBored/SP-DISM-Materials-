// Name: Leonard Soh //
//   Initials: LS   //
console.log("*          *****");
console.log("*         ***");
console.log("*           **");
console.log("*            **");
console.log("*            ***");
console.log("******   *****  ");