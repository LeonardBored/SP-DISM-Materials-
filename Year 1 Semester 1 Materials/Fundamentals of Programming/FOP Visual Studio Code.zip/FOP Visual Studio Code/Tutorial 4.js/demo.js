age = 13

if (age>=10 && 20<=age) {
console.log(age)
} else {
    console.log("no")
}