const fs = require('fs'); // Imported from fs to append file //

var orderCart = []      // Sets as an empty array first //
var pricePerOrder = []  // Sets as an empty array first //
var totalPrice = 0      // Sets total price as 0 first //
var orderReceipt = "Empty Receipt, Please add orders to cart" // Text in orderReceipt.txt as default //
var discountedPrice = 0                                       // Sets discounted price as 0 first //
var orderNum = Math.floor(Math.random()*100000 +1)            // Randomly generated order Number //
receiptCounter = 1      // Set receipt counter as 1 first for first order //

// Function used to display error in input //
function errorMessage() {                     
    if (input != 0) {     // Ensure that input == 0 won't print invalid //
    console.log("\x1b[31m%s\x1b[0m","Invalid Number! Please re-enter a valid number.")  
    }
}

// Function is used to print out the orders and to ensure that there are orders before printing of all orders //
function viewOrders() {
    if (orderCart.length == 0) {                      // checks if cart is empty //
        console.log("\x1b[31m%s\x1b[0m","\nEmpty Cart, Please Add orders to cart")
        input = 0                                     // sets input = 0 so it will go back to main menu //
        orderNum++                                    // Order number changes when cart becomes empty //
    } else if (input != 0) {
        for(i = 0 ; i < pricePerOrder.length ; i++) { // Calculates total price first before printing it //
            if (i > 0) {
            totalPrice += pricePerOrder[i]            // if there is more than one order, sum up the cost of all orders //
            } else {
                totalPrice = pricePerOrder[0]         // Makes total price = to first element of pricePerOrder array when there is only 1 order left //
            }          
        }   
        orderReceipt = "\n^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-\nOrder number: W" + orderNum  // Assign a unqiue order id from 1 to 100000 when order is being added to receipt //
        orderReceipt += "\n{ Your Cart : }\n======================================================================\n"
        for (i=1 ; i<= orderCart.length ; i++) {                                                                                                                              // Loops through orderCart Array //
            orderReceipt += i + ". " + orderCart[i-1]+"\n"                                                                                                                    // Data is put into orderReceipt and made into a string //
        }
        orderReceipt += "======================================================================\n"
        orderReceipt += "\n\t\t{ Original Total Cost : $ " + totalPrice.toFixed(2) + " }"                                                                                      // Print out totalCost calculated from for loop above //
        orderReceipt += "\n\t\t{ Discount : $ " + discountedPrice.toFixed(2) + " }"                                                                                            // Print out Discount if there is any //
        orderReceipt += "\n\t\t{ Final Cost : $ " + (totalPrice - discountedPrice).toFixed(2) + " }\n\nv-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-v-" // Prints out the final price if there is discount or not //
        console.log("\x1b[33m%s\x1b[0m",orderReceipt)                 // Prints in string yellow color //
    }
}

// This function lets the user input the index of an order to remove it from the order receipt. // 
function removeOrder() {
    while(input != 0) {
        input = readline.questionInt("\nRemove Item\nEnter Item Number\n0. Return to main menu\n>>> ")
        
        if (input < 0 || input > pricePerOrder.length) { // ensures that input is in range of the length of the array //
            errorMessage()  
        } else if (input != 0) {                                 // Ensures that input != 0  //
            totalPrice -= pricePerOrder[input - 1]               // Subtracts total price from element removed in array //
            pricePerOrder.splice(input - 1 , 1)                  // Removes element from pricePerOrder array according to index //
            orderCart.splice(input - 1 , 1 )                     // Removes element from orderCart array according to index //
            console.log("\x1b[32m%s\x1b[0m","\nItem Removed!\n") // Prints out item removed to allow user to know //
            break;                                               // This break allows it to go back to previous loop of cart option //
        } 
    }
}

// This function removes all orders in the order receipt //
function removeCart() {
    orderReceipt = "Empty Receipt, Please add orders to cart" // Resets string in txt file //
    pricePerOrder.length = 0 // Resets array //
    orderCart.length = 0     // Resets array //
    input = 0                // To go back to main page //
}

// This function appends all orders that the user has made onto the file orderReceipt.txt and resets the order cart //
function receipt() {
    try {                                                            // This function replaces content in a created textfile or create a file and append it if it does not exist //
        fs.writeFileSync("./p2006264_leonardsoh/FOP CA2/order_receipts_folder/orderReceipt"+receiptCounter+".txt",orderReceipt); // This creates a file in the order_receipts_folers with parameteters(File folder create,data to append) // 
        receiptCounter++         // Increments the counter such that it creates a brand new file for a new order //
        pricePerOrder.length = 0 // Resets array //
        orderCart.length = 0     // Resets array //
    } catch(err) {                                                   // To ensure that it is appended onto the whole order log to keep track of all orders //
        console.error(err) 
    }
}

// this function will allow for a discount in price of all the orders if the user types in the correct discount code //
function discount() {               // Will Ask and check for discount code  //
    while(input != 0) {
        input = readline.question("\nEnter a discount Code\nReturn to main menu\n>>> ")
        if (input == "redeem") {                // checks for discount code : redeem //
            discountedPrice = 0.15 * totalPrice // discounts 25% of total price //
            console.log("\x1b[32m%s\x1b[0m","\nDiscount Redeemed!\n")
            break;                              // Break out of the loop and function //
        } else if (input != 0) {                // Ensures that input != 0 and that discount code entered is not valid //
            console.log("\x1b[31m%s\x1b[0m","\nPlease enter a valid discount code")
        }
    }
}

// This function is a lucky draw which offeres discount if the random number generated from 1-10 is equal to another random number generated from 1-10
function luckyDraw() {                                                                        // Chances of winnning 1/100 (1/10 x 1/10) //
        var chance = Math.floor(Math.random()*9 + 1)                                          // Chance is assign a random number from 1-10 //
        if (chance == Math.floor(Math.random()*9 + 1)) {                                      // Chance is checked whether it is equal to another randomly generated number from 1-10 // 
            discountedPrice = 0.15 * totalPrice                                               // Discount is given if user wins the lucky draw //
            console.log("\x1b[32m%s\x1b[0m","Congratulations! You have won the lucky draw!")  // let users know they won the lucky draw //
        } else {                                                                              // When user loses the lucky draw //
            console.log("\x1b[31m%s\x1b[0m","Too bad, Try again next time!")                  //Let users know that they lost the lucky draw //
        }
}

module.exports = { viewOrders,removeOrder,receipt,removeCart,discount,luckyDraw,orderCart,pricePerOrder }; // Exports cart option functions to main and arrays orderCart + pricePerOrder to offerings // 