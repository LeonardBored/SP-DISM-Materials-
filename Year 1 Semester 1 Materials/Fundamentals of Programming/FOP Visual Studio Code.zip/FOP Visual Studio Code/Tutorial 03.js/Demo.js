var bicycleType, hours, fee, bicyclePrice;
var readline = require('readline-sync')
bicycleType = readline.questionInt('Enter bicEnter bicycle type:\n(1)\tSingle Seater\t(2)\tDouble Seater\n>>')
hours = readline.questionFloat('Enter number of hours rented: ')
bicyclePrice = [5.5,7.8]
if (hours >= 3) {
    fee = bicyclePrice[bicycleType - 1] * hours * 0.7
}
else {
    fee = bicyclePrice[bicycleType - 1] * hours
}
console.log('Total Rental Fee: $' + fee)