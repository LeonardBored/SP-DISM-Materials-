class Circle {
    constructor(radius) {
        this.radius = radius
    }

    getArea() {
        var area = Math.PI*(this.radius**2) 
        return area;
    }

    enlargeCircle() {
        this.radius *= 3
    }

    shrinkCircle() {
        this.radius *= 0.5
    }
}

var circle1 = new Circle(2)
console.log("Area of circle1 with radius 2.0 is " + circle1.getArea())

circle1.enlargeCircle()
console.log("\nCircle is enlarged 3 times\nArea of circle1 with radius 6.0 is " + circle1.getArea())

circle1.shrinkCircle()
console.log("\nCircle is shrunk by halve\nArea of circle1 with radius 3.0 is " + circle1.getArea())