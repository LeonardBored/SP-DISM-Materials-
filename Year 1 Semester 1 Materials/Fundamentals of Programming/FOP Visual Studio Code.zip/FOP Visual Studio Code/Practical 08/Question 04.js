class Fan {
    constructor(on,speed) {
        this.speed = speed
        this.on = on
    }
    getState() {
        if (this.on == "false") {
            console.log("Off")
        } else {
            switch(this.speed) {
                case 1 : 
                    console.log("On at slow speed")
                    break;
                case 2 : 
                    console.log("On at medium speed")
                    break;

                case 3 : 
                    console.log("On at fast speed")
                    break;
                default : 
                    console.log("Error, please type in a valid speed from 1 to 3")
            }
        }
    }
}

var readline = require('readline-sync')
var ifOn = readline.question("Is fan on? Answer true or false : ")
var whatSpeed = readline.questionInt("What is the speed of the fan? Enter 1 to 3 : ")

var fan1 = new Fan(ifOn,whatSpeed)

fan1.getState()