class BankAccount {
    constructor(name, savings) {
        this.name = name
        this.savings = savings
    }

    getBalance() {
        var s = "\n"
        s += this.name + " has $" + this.savings.toFixed(1)
        console.log(s)
    }
}

var account1 = new BankAccount("Oliver Twist", 1000)
account1.getBalance()

var account2 = new BankAccount("Richie Rich", 100000)
account2.getBalance()