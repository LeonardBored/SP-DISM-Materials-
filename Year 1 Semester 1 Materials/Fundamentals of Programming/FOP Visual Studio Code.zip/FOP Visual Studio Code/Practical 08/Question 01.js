class Rectangle {
    constructor(length, width) {
        this.length = length
        this.width = width
    }

    getArea() {
        var area = this.length * this.width
        return area
    }

    getPerimeter() {
        var perimeter = 2*this.length + 2*this.width
        return perimeter
    }
}

var r1 = new Rectangle(10,5)
console.log("Area of rectangle r1 is " + r1.getArea() + "\nPerimeter of rectangle r1 is " + r1.getPerimeter())
