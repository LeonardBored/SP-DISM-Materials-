function createSquareArray() {

    var len;
    var sqArray = [];

    for(i=0; i<10; i++) {
        len = 10 + Math.floor(Math.random() * 11);
        sqArray.push(len);
    }

    return sqArray;
} 

function printSquareArray(arrayInput) {
    console.log("Square Array")
    for (i=0; i<arrayInput.length; i++) {
        console.log(arrayInput[i])
    }
}

var myArray = createSquareArray();
printSquareArray(myArray);
