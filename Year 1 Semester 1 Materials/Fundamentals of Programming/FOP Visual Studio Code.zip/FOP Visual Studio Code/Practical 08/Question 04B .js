class Fan {
    constructor(on,speed) {
        this.on = on
        this.speed = speed
    }
    getState() {
        if (this.on == false) {
            return "Off"
        } else {
            switch(this.speed) {
                case 1 : 
                    return "On at low speed"
                case 2 : 
                    return "On at medium speed"
                case 3 : 
                    return "On at fast speed"

                default : 
                    return "Error, please type in a valid speed from 1 to 3"
            }
        }
    }
}

var fan1 = new Fan(true,1)
var fan2 = new Fan(true,3)
console.log("fan1 is " + fan1.getState())
console.log("fan2 is " + fan2.getState())
fan1.on = false
fan2.speed = 2
console.log("fan1 is " + fan1.getState())
console.log("fan2 is " + fan2.getState())
