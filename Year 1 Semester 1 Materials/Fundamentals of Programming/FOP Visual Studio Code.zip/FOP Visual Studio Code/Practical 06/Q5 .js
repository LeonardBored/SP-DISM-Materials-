var intArray = new Array(50);
var oddArray = [];
var evenArray = [];
var intString = ""
var oddString = ""
var evenString = ""
for (i = 0 ; i < intArray.length ; i++) {
    intArray[i] = Math.floor(Math.random()*100 + 1)
    intString += intArray[i] + " "
    if (intArray[i] % 2 == 0) {
        evenArray[i] = (intArray[i])
        evenString += evenArray[i] + " "
    } else {
        oddArray[i] = intArray[i]
        oddString += oddArray[i] + " "
    }
}
console.log("Original Array : \n" + intString + "\n")
console.log("Even Numbers : \n" + evenString + "\n")
console.log("Odd Numbers : \n" + oddString + "\n")