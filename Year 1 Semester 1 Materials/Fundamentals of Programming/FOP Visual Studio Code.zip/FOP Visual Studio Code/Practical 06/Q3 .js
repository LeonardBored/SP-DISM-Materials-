var list1 = [12, 56, 76, 32, 12, 34]
var list2 = [12, 56, 76, 32, 12, 34]
var valueEqual = false;
for (i = 0 ; i <= list2.length ; i++) {
    if (list1.length == list2.length) {
        valueEqual = list1[i] == list2[i]
        if (valueEqual == false) {
            break;
        }
    }
}

if (valueEqual == true) {
    console.log("Two lists are stricly identical")
} else if (valueEqual == false) {
    console.log("Two lists are not identical")
} else {
    console.log("Error!")
}