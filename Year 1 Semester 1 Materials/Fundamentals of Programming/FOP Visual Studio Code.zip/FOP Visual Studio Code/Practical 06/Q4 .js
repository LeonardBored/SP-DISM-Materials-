var intArray = new Array(5)
var max;
for (i = 0 ; i < 5; i++) {
    intArray[i] = Math.floor(Math.random() * 12)
}

max = intArray[0]

for (i = 1 ; i < 5 ; i++) {
    if (max < intArray[i]) {
        max = intArray[i]
    }
}

console.log("Elements of int array : " + intArray)
console.log(max)