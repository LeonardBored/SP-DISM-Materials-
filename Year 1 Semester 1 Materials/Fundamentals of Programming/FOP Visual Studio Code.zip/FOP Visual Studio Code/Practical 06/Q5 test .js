var intArray = new Array(50)
var oddArray = []
var evenArray = []
var s = ""

for(var i = 0 ; i <= intArray.length - 1 ; i++) {
    intArray[i] = Math.floor(Math.random()*100 + 1)

    if (intArray[i] % 2 == 0 ) {
        evenArray.push(intArray[i])
    } else {
        oddArray.push(intArray[i])
    }
}

console.log("Original Array :\n" + intArray + "\n")
console.log ("Even numbers :\n" + evenArray + "\n")
console.log("Odd Numbers :\n" + oddArray + "\n")
