# StudentID:    P2006264
# Name:	        Soh Kai Meng Leonard
# Class:		DISM/FT/1B/05 
# Assessment:	CA1 
# 
# Script name:	User.py
# 
# Purpose:	For user to take quiz and store their attempt in quiz_results.csv
#
#   Firstly user will be prompted to login using their userID and password. 
#   Programme will only accept valid userIDs and their respective passwords stored in userid_pswd.txt
#   User can also choose to forget password in order to reset password. User will have to enter appropriate userID
#   and email address allocated to it in userid_pswd.txt in order to be able to reset their password
#   
#   After successful Login, User can choose to take quiz or view their previous attemptsS
#   Once user have finished taking the quiz, results will be printed for user and attempt will be stored in quiz_results.csv
#
#
# Usage syntax:	Run with play button
# 
# Input file:	
#
# './Text_Files/question_pool.txt'
# './Text_Files/quiz_setting.txt'
# './Text_Files/userid_pswd.txt'
# './Text_Files/quiz_results.csv'
# 
# Output file:	
#
# './Text_Files/userid_pswd.txt'
# './Text_Files/quiz_results.csv'
# 
# Python ver:	Python 3
#
# Reference:
#       
#       (a) Python time Module 
#           https://www.programiz.com/python-programming/time 
#           accessed on 20 Nov 2021
#
#       (b) Working with csv files in Python 
#           https://www.geeksforgeeks.org/working-csv-files-python/ 
#           accessed on 19 Nov
#
#       (c) Python CSV 
#           https://www.programiz.com/python-programming/csv 
#           accessed on 19 Nov
#
#       (d) Python Random shuffle() Method 
#           https://www.w3schools.com/python/ref_random_shuffle.asp
#           accessed on 15 Nov 2021
#       
# Library/:	
# package/:	
# Module/:
# 
# Random Module 
# Time Module
# CSV Module
#
# Known issues:	eg. no validation of input value
#
# ****************************** User-defined functions ***************************
# Describe the purpose of user-defined functions, parameters and return values

# This function checks for userInput and only accepts if userInput is within the range specified
# The argument of this function takes in the start and end integer values and finally the question being asked
# The function returns a valid integer number between the range specified in the argument
def validationRange(start,end,question): 
    while True:
        try:
            checkInput = int(input(question))
            if checkInput < start or checkInput > end:
                raise OverflowError
            else:
                return checkInput
        except OverflowError:   # for out of range
            print('\33[41m' +f'Out of range! Please enter an integer number between {start} and {end}'+ '\33[0m' +'\n')
        
        except ValueError:      # for not int number input 
            print('\33[41m'+ f'Invalid, not int. Please enter an integer number between {start} and {end}'+'\33[0m' + '\n')

        except EOFError:        # error for when user enters ctrl + z
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')
        except KeyboardInterrupt:   # Error for when user enters ctrl + c
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')


# This function checks for any illegal char used in user inputs and rejects it if it is found. 
# The argument of this function takes in the question being asked
# The function returns a valid string that does not contain illegal char in the specialCharList
def stringValidation(question):
    specialCharList = ['~','`','`','\ ','|']
    while True: 
        try:
            counter = 0   
            checkInput = input(question)
            checkInput = checkInput.strip() # Removes spaces
            if checkInput == '':
                counter += 1
                print('\33[41m' + 'Empty input! Please re-enter again' + '\33[0m' + '\n')

                
            for char in specialCharList:
                # Ensure user input no special char
                if checkInput.find(char) != -1:   # If input contains special char : reject it
                    print('\33[41m' + f'Invalid char {char} entered! Please re-enter again' + '\33[0m' + '\n')
                    counter += 1
                    break

            if counter == 0:                
                return checkInput   # Validated after no special char in input

        except EOFError:            # error for when user enters ctrl + z
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')
        except KeyboardInterrupt:   # Error for when user enters ctrl + c
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')

# This function takes in a list and question as parameters and ensures that user Input is an element in the given list
# The argument of this function takes in a list and the question being asked
# It returns a valid input that is inside the specified list in the argument
def listRangeValidation(list,question):
    while True: 
        try: 
            checkInput = input(question)
            checkInput = checkInput.strip()
            for char in list:
                if checkInput == char:      # if input is found within the list
                    return checkInput       # Returns input
            print('\33[41m' + f'Invalid char entered! Please re-enter a option from {list}'+ '\33[0m' +'\n')

        except EOFError:            # error for when user enters ctrl + z
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')
        except KeyboardInterrupt:   # Error for when user enters ctrl + c
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')

# This function creates a dictionary. The number of key = the number of lines of the given txt file
# In each key, there will be a list of items, made by .split('|')
# The argument of this function takes in a textfile's pathway
# It returns a dictionary created based on the data stored in the text file
def readFile(txtFile):
    dict = {}
    with open(txtFile,'r') as fn:       # Opens the given text file in read mode
        for i, line in enumerate(fn):   # For each line in the given txt file
            line = line.strip()         # Removes any spaces + '\n'
            dict[f'{i + 1}'] = line.split('|')    # Creates a list with the seperator '|' seperating each element

    # Checks for any empty list that were stored in dictionary keys
    emptyKeyList = []
    for key in dict:
        if dict[key] == ['']:
            emptyKeyList.append(key)
    
    # Deletes dict key that contains empty list as it is invalid
    for key in emptyKeyList:    
        del dict[key]
    
    return dict   # Returns the created dictionary


# This function prints the selected question in the questionPool dict
# The argument of this function is the key of the selected question, its question pool dictionary and index (used for indexing of question)
def printSelectedQuestion(selectedQuestion,dictionary,index):
    print('\n---------------------------------------------\n')
    print('\n'+ '\33[32m' +f'Question {index}: ' + '\33[0m' f'\n{dictionary[selectedQuestion][0]} ({dictionary[selectedQuestion][6]}m)')
    for i in range(4):   # Printing of options 
        print(f'{dictionary[selectedQuestion][i+1]}')
    
    print('\n---------------------------------------------\n')

# This function creates a list that stores dictionaries from the chosen csv file
# This function takes in a chosen csv file's path as its argument
# It returns a list containing dictionaries where each dictionary represents a row in the csv file
def readCSV(csvFile):
    # list that contains all previous attempts stored in csv file
    dataList = []
    # Reading of previously stored data in csv file and store in a list
    with open(csvFile,'r') as file: # Read mode
        writer = csv.DictReader(file)
        for line in writer:
            # Appends each attempt into list as a dictionary
            dataList.append(dict(line))
    
    # Returns created dataList
    return dataList

#
# ******************************* Main program ***********************************


# Insert clear description to facilitate maintenance of script in the future

import random
import time
import csv

# Global variabes that contains the pathway to individual text files
questionPoolTxt = './Text_Files/question_pool.txt'
quizSettingTxt = './Text_Files/quiz_setting.txt'
userID_pwdTxt = './Text_Files/userid_pswd.txt'
resultsCsv = './Text_Files/quiz_results.csv'

# This function calculates the results of the quiz based on user input in answerList and answer that was inside the quesion pool.
# It will then collate the total marks and give a report + grade
# It then data into quiz_results.csv the attempt
# The argument of this function takes in the userID of the user, the answerlist,
# the selected questions key used in the list and the question pool dict, time used for quiz, and the number of questions answered
def calculateResults(userID,answer,selectedQuestionKey,questionpoolDict,timeUsed,numOfAnswered):
    correctAnswerList = []
    totalPossibleMarks = 0
    totalMarks = 0
    numOfCorrect = 0
    timeSubmitted = time.ctime(time.time())   # Gets time when quiz was submitted
    
    # Storing of correct answers + total possible marks
    for i in selectedQuestionKey:
        correctAnswerList.append(questionpoolDict[f'{i}'][5])   # Make a list filled with the correct answers
        totalPossibleMarks += int(questionpoolDict[f'{i}'][6])  # Collate total marks
    
    # Checks for correct answer and add marks accordingly
    for i, s in enumerate(correctAnswerList):
        if s == answer[i]:
            totalMarks += int(questionpoolDict[f'{selectedQuestionKey[i]}'][6]) # If answer is correct, add that marks allocated to the question to total marks
            numOfCorrect += 1                     # Adds 1 to the number of correct answer
    
    scorePercent = (totalMarks / totalPossibleMarks) * 100

    # Formatting of quiz results printing
    resultsMenu =  '\33[32m' + 'Results' + '\33[0m' +f'\n==============================================\n{userID}' 
    resultsMenu += '\nResults : ' + '\33[32m' + f'{scorePercent:.2f} %' + '\33[0m' 
    resultsMenu += f'\nNumber of questions answered: {numOfAnswered} / {len(correctAnswerList)}'
    resultsMenu += f'\nTotal Marks: {totalMarks:.2f} / Total Possible Marks : {totalPossibleMarks:.2f}'
    resultsMenu += f'\nTime Taken: {timeUsed} min'
    resultsMenu += f'\nTime Submitted: {timeSubmitted}'
    resultsMenu += f'\nNumber of correct answers {numOfCorrect} / {len(correctAnswerList)}' + '\n'

    if scorePercent <= 40:
        resultsMenu += '\n' + '\33[41m' + 'Poor! You will have to work harder.' + '\33[0m'
    
    elif scorePercent < 80: 
        resultsMenu += '\n' + '\33[46m' + 'Fair. You can do better with more effort.' + '\33[0m'
    
    # For percentage 80% to 100%
    else: 
        resultsMenu += '\n' + '\33[42m' + 'Good! Well done.'  + '\33[0m'
    
    resultsMenu += '\n==============================================\n'
    print(resultsMenu)
    input('\33[42m' + 'Press enter to continue...' + '\33[0m' + '\n')



    # Sort the array such that key is in ascending order
    selectedQuestionKey.sort()

    # Creates a dictionary to store all of quiz data for the current attempt
    resultDict = {  'UserID' : userID,
                    'Grade (%)' : f'{scorePercent:.2f}',
                    'Number of Question Tested' : str(len(correctAnswerList)),
                    'Number of Question Answered' : numOfAnswered,
                    'Number of Correct Answer' : str(numOfCorrect),
                    'Total Marks' : f'{totalMarks:.2f}',
                    'Total Possible Marks': f'{totalPossibleMarks:.2f}',
                    'Time Used (min)' : timeUsed,
                    'Time Submitted' : timeSubmitted }

    # Creates key and input appropriate values and generate fieldnames accordingly
    for i, key in enumerate(questionpoolDict):
        resultDict[f'Question {i+1}'] = questionpoolDict[key][0]         # Question
        resultDict[f'Q{i+1} Correct Answer'] = questionpoolDict[key][5]  # Correct Answer for Question
        
        # If user did this question, store the user's answer along in the list
        if key in selectedQuestionKey:
            # If question is unanswered, store it as unanswered. Else, store it as what user have answered
            # selectedQuestionKey.index(key) finds the index where key is found in selectedQuestionKey list
            # it then checks if user have attempted the question or skip it
            # len(selectedQuestionKey) == len(answer)
            if answer[selectedQuestionKey.index(key)] == None:
                resultDict[f'Q{i+1} User Answer'] = 'Unanswered'
            else:
                resultDict[f'Q{i+1} User Answer'] = answer[selectedQuestionKey.index(key)]
        
        else: # if key is not in selectedQuestionKey List, it means it is not tested
            resultDict[f'Q{i+1} User Answer'] = 'Not Tested'

    # Datalist is a list that contains each previous attempts in dictionaries
    dataList = readCSV(resultsCsv)

    # Header of the csv file is contained within field list
    field = []
    for dictionary in dataList:
        for key in dictionary:
            # Appends all keys that attempt 1 has if it exists in csv file
            field.append(key)
        break
    
    # For when headers is empty (csv file is empty) or if headers contains lesser values than current attempt (new question added)
    if field == [] or len(field) < len(resultDict.keys()):
        field.clear()              # Resets field list to []
        for key in resultDict:
            field.append(key)      # Appending of old header

    # Appends the current attempt into the dataList(contains all previous known attempts)
    dataList.append(resultDict)
    
    # For any key that == '', it means that a new question(column) got added previously and previous attempts will have a new column
    # Helps to indicate that question did not exist in the quiz in the first place for that attempt
    for dictionary in dataList:
        for key in dictionary:
            if dictionary[key] == '':
                dictionary[key] = 'Did not exist in this quiz'

    # Writing of data into csv file
    with open(resultsCsv,'w') as fn: # write mode

        # Using dict writer as data is stored in dict
        writer = csv.DictWriter(fn,fieldnames = field)

        # Writing Headers (field names)
        writer.writeheader()
        
        # Writing of data rows
        writer.writerows(dataList)

# This function checks whether user has any attempts left and returns the number of attempts user has made
# It takes in the current user ID as the argument
def checkAttempt(userID):
    # Number of attempts user have used
    numOfAttempts = 0

    # Datalist is a list that contains each attempts in dictionaries
    dataList = readCSV(resultsCsv)

    # For each attempt, under the key 'UserID', if both userIDs matches add one to numOfAttempts
    for dictionary in dataList:
        if userID == dictionary['UserID']:
            numOfAttempts += 1

    return numOfAttempts

# This function, takeQuiz first prompts the user to confirm take quiz
# If user confirms to take quiz, then it will create a random question list based on number of questions set in quiz settings\
# User will then take quiz with selected randomized questions where user answers will be stored in answerList
# This function will then go to calculateResults() function once user successfully submits to calculate results
# The argument of this function is the UserID of the successful login
def takeQuiz(userID):
    # Reading of question Settings
    quizSettings = readFile(quizSettingTxt)
    questionPool = readFile(questionPoolTxt)
    
    # Checks if question pool or quiz setting is empty
    if questionPool == {} or quizSettings == {}:
        emptyDict = True
    else:
        # Ensure that even if quiz setting is filled, it is with appropriate data and not the default empty
        if quizSettings['1'][1] == 'empty' or quizSettings['2'][1] == 'empty' or quizSettings['3'][1] == 'empty':
            emptyDict = True
        else:
            emptyDict = False


    # if both question pool and quiz setting is not empty, proceed to quiz
    if emptyDict == False:

        questionPoolKeyList = []
        timeOfQuiz = quizSettings['1'][1]
        noOfQuestions = quizSettings['2'][1]
        noOfAttempts = quizSettings['3'][1]

        # Checks for how many attempts user has made
        numOfUserAttempts = checkAttempt(userID)
        remainingAttempts = int(noOfAttempts)-numOfUserAttempts

        # for when quiz Setting changes and amt of attempts left becomes negative, set remaining attempts to 0
        if remainingAttempts < 0:
            remainingAttempts = 0

        takeQuizMenu = '\n-------------------------------------------------\n' + '\33[32m' + '\t\t' + '\33[4m'+ '\ Confirm Take Quiz /' + '\33[0m'
        takeQuizMenu += f'\n\nNumber of Attempts Left: {remainingAttempts}'
        takeQuizMenu += f'\nTime allowed: {timeOfQuiz} min'
        takeQuizMenu += f'\nNumber of Questions: {noOfQuestions}'
        takeQuizMenu += '\n\n[1] Yes \t [0] No (Back)'
        takeQuizMenu += '\n\n-------------------------------------------------\n'

        confirmOption = validationRange(start=0,end=1,question=takeQuizMenu)

        if confirmOption == 1 and remainingAttempts != 0:
            for key in questionPool:
                questionPoolKeyList.append(key)

            # Shuffles the question key pool to randomize questions that are selected
            random.shuffle(questionPoolKeyList)
            
            # Set the no of questions in questionPoolKeyList to be that of what was stated in quiz settings 
            questionPoolKeyList = questionPoolKeyList[0:int(noOfQuestions)]
            
            # Makes an empty list whcih has a length equal to number of questions being tested 
            # List contains [None,None,None,...] Number of elements in list is equal to number of questions being tested
            answerList = [None]*len(questionPoolKeyList)

            print(f'\n{userID}, Please Choose the best answer for questions.\nTime allowed: {timeOfQuiz} min\n')

            # Intializing of i and key for while True loop 
            i = 0
            key = questionPoolKeyList[i]
            
            # use time module to get seconds since 1970 for storing of time quiz should end
            endTime = time.time() + int(timeOfQuiz) * 60

            # Quiz Loop where they will ask questions chosen from randomized questionPoolKeyList. 
            # Only accept user input a,b,c,d,P,p,N,n
            # P for previous question
            # N for next question
            # User input (answer) is stored in answerList 
            while True:
            
                # Checking of any unaswered questions for when time is out
                unansweredQuestionList = []
                unansweredQuestion = False

                # Check through answerList and check if there is any value which is None. Count is used to count num of questions answered
                count = len(questionPoolKeyList)
                for s, userAnswer in enumerate(answerList):
                    if userAnswer == None:
                        unansweredQuestionList.append(s+1)
                        unansweredQuestion = True
                        count -= 1

                # Gets time left in min (-0.40 as it starts from 1.00 for each min)
                timeLeft = (endTime - time.time()) / 60 - 0.40

                # If time is up, auto submit it after next user input
                if timeLeft <= 0:
                    print('\n' + '\33[41m' + 'Time is up! Submitting Test now...' + '\33[0m' + '\n')
                    # The parameter takes in the userID of the user, the answerlist, the selected questions used in the list, question pool dict and time taken
                    calculateResults(userID,answer=answerList,selectedQuestionKey=questionPoolKeyList,questionpoolDict=questionPool,timeUsed=timeOfQuiz,numOfAnswered=count)
                    break    # Breaks out of while true loop after calculateResults function

                # Prints selcted question given the question key
                printSelectedQuestion(selectedQuestion=key,dictionary=questionPool,index=i+1)
                
                print('Current Time Left: ' + '\33[32m' + f'{timeLeft:.2f} (min/s)' + '\33[0m')

                # Shows previous submitted answer for previous questions if user presses P after entering an answer
                if answerList[i] != None:
                    print('Previous Answer submitted: ' + '\33[32m' + f'{answerList[i]}' + '\33[0m' + '\n')
                
                # Gets user input for answer of quiz
                answer = listRangeValidation(list=['a','b','c','d','P','p','N','n'],question='<Enter (a) to (d) for answer, P for previous question, N for next question>\n>>> ')

                # If user enters answer, store it in answerList and go to next question
                if answer.upper() != 'P' and answer.upper() != 'N':
                    answerList[i] = answer + ')'  # Storing of answer in answerList
                    i += 1                        # Adds one to i

                    # For last question, ask for submit
                    if i == len(questionPoolKeyList) :
                        confirmSubmitMenu = '\nEnter' + '\33[32m' + ' 0 ' + '\33[0m' + 'to submit your quiz or ' +'\33[91m' + f'[1 to {i}] ' + '\33[0m' + 'to change your answer.\n >>> '
                        
                        # Checking of any unaswered questions again for final question
                        unansweredQuestionList.clear()   # Clears list
                        unansweredQuestion = False       # Reset check

                        # Check through answerList and check if there is any value which is None. Count is used to count num of questions answered
                        count = len(questionPoolKeyList)
                        for s, userAnswer in enumerate(answerList):
                            if userAnswer == None:
                                unansweredQuestionList.append(s+1)
                                unansweredQuestion = True
                                count -= 1

                        # IF there are unanswered questions, let user know
                        if unansweredQuestion == True:
                            print('\33[41m' + f'Unanswered Question(s): {unansweredQuestionList}' + '\33[0m' + '\n')  

                        confirmSubmit = validationRange(start=0,end=i,question=confirmSubmitMenu)
                        # Submission of quiz
                        if confirmSubmit == 0:
                            input('\33[42m' + '\nQuiz Submitted! Press enter to continue...' + '\33[0m' + '\n')
                            
                            timeTaken = str(int(timeOfQuiz) - int(timeLeft))
                            
                            # The parameter takes in the userID of the user, the answerlist, the selected questions used in the list, question pool dict and time taken
                            calculateResults(userID,answer=answerList,selectedQuestionKey=questionPoolKeyList,questionpoolDict=questionPool,timeUsed=timeTaken,numOfAnswered=count)
                            
                            # Break out of while True loop to go all the way back to main menu page
                            break 

                        # For when user chooses to change an answer of a selected question
                        else:
                            i = confirmSubmit - 1 # -1 as for last element, there is a += 1 above

                    key = questionPoolKeyList[i]  # sets key to current question where index i is

                # Go to next question when i < index of last question
                elif answer.upper() == 'N' and i < len(questionPoolKeyList) -1:
                    i += 1
                    key = questionPoolKeyList[i]
                # For when user tries to get to next question at last question when i > index of last question
                elif answer.upper() == 'N' and i >= len(questionPoolKeyList) -1: 
                    print('\n'  + '\33[41m' + 'Error! Your are attempting last question. Cannot go to next question' + '\33[0m' + '\n')

                # Go to previous question when i >= index of first questtion, 0
                elif answer.upper() == 'P' and i >= 1: 
                    i -= 1
                    key = questionPoolKeyList[i]
                
                # For when user tries to go to previous question at Question 1 when i < index of first question,0
                elif answer.upper() == 'P' and i < 1:
                    print('\n'  + '\33[41m' + 'Error! You are attempting first question. Cannot go back to previous question' + '\33[0m' + '\n')
        
        # For when user tries to enter quiz but has used up all attempts
        else:
            if confirmOption != 0:  # If user presses 1 instead of 0 since 0 is used to go back
                print('\n'  + '\33[41m' + 'Error! You have used up all attempts. Cannot attempt quiz again' + '\33[0m' + '\n')

    # Error for when quiz settting is empty or when question pool is empty
    else: 
        print('\n'  + '\33[41m' + 'Error! Quiz Setting or Question Pool is empty! Please contact administrators for help' + '\33[0m' + '\n')

# This function allows the user to view their previous attempts 
# It gives a stats on each attempt
# It takes in the user ID of a chosen user as the argument
def viewResults(userID):
    
    # Datalist is a list that contains each attempts in dictionaries
    dataList = readCSV(resultsCsv)
    # Index used for for loop printing
    i = 0
    # ResultsMenu used for checking 
    resultsMenu = None
    # Loop through each dictionary in dataList
    for dictionary in dataList:
        # Finds user attmpets given the userID
        if dictionary['UserID'] == userID:
            i += 1
            # Formatting of quiz results printing
            resultsMenu =  '\n' + '\33[32m' + f'Results for attempt {i}:' + '\33[0m' +f'\n------------------------------------------------------\n{userID}' 
            resultsMenu += '\nResults : ' + '\33[32m' + dictionary['Grade (%)'] +' %' + '\33[0m' 
            resultsMenu += '\nNumber of questions answered: ' + dictionary['Number of Question Answered'] + ' / ' + dictionary[ 'Number of Question Tested']
            resultsMenu += '\nNumber of correct answers ' + dictionary['Number of Correct Answer'] + ' / ' + dictionary['Number of Question Tested']
            resultsMenu += '\nTime Taken: ' + dictionary['Time Used (min)'] + ' min\n'
            resultsMenu += '\nTime Submitted: ' + dictionary['Time Submitted']
            resultsMenu += '\n------------------------------------------------------\n'
            print(resultsMenu)
            
            input('\33[42m' + 'Press enter to continue...' + '\33[0m' + '\n')

    # Error message if user did not attempt quiz
    if resultsMenu == None:
        print('\n' + '\33[41m' + 'Error! No attempts made to quiz' + '\33[0m' + '\n') 

# this function serves as a purpose of main menu after user successfully logins
# The argument of this function is the UserID of the successful login
def mainMenu(userID):
    while True:
        mainMenu = '\n==============================================\n' + '\33[32m' + '\t\t' + '\33[4m'+ '\ Main Menu /' + '\33[0m'
        mainMenu += f'\n\nWelcome {userID}!\n[1] Take Quiz\n[2] View Current Results\n[0] Logout'
        mainMenu += '\n\n==============================================\n>>> '

        chosenOption = validationRange(start=0,end=2,question=mainMenu)
        if chosenOption == 0:
            break

        # Take Quiz
        elif chosenOption == 1:
            takeQuiz(userID)

        # View of current user Results
        elif chosenOption == 2:
            viewResults(userID)

# This function checks for the correct userID and password entered by user before allowing it to go to main menu
# The argument passed through it is a dictionary containing users and their respective passwords
# This dictionary will be used for checking user login
def loginUser(dict):
    while True:
        checkUserID = stringValidation(question='\n'+ '\33[32m' +'\33[4m'+  'Please Enter Your User ID' + '\33[0m'  +'\n[0] Back to login page\n>>> ')

        if checkUserID == '0':
            break

        elif checkUserID == '':
            print('\33[41m' + 'Error! Empty String. Please re-enter username again' + '\33[0m')
        
        else:
            # Formatting of userID to match it in dict. Format is UserID: .... 
            checkUserID = 'UserID: ' + checkUserID + ' '

            checkPwd = stringValidation(question='\n' +'\33[32m'+ '\33[4m' +'Please Enter Your Password' + '\33[0m' + '\n[0] Back to Entering username\n>>> ')

            if checkPwd != '0':

                # Formatting of pwd to match it in dict. Format is pwd: wla....
                checkPwd = ' pwd: wla' + checkPwd[::-1]

                # For each username and password stored in userDict, check if userID and password both matches
                for key in dict:
                    if checkUserID == dict[key][0]: # Checks if username is equal to stored password
                        correctUserID = True
                        if checkPwd == dict[key][1]: # Checks if password is equal to stored password
                            correctPwd = True
                            break
                        else: 
                            correctPwd = False
                    else: 
                        correctUserID = False
                        correctPwd = False

                # When password and userID matches, accept and go to main menu
                if correctPwd and correctUserID == True:
                    input('\33[42m' + '\nLogin Success! Press enter to continue...' + '\33[0m' + '\n')
                    return checkUserID
                
                else: 
                    print('\n'  + '\33[41m' + 'Error! UserID or Password is invalid! Please re-enter information again' + '\33[0m' + '\n')

# This function ensures that password contains special char + minimum length of 8
# The argument of this function takes in the question being used to prompt user
def pwdCheck(question):
    while True: 
        specialCharList = ['@','#','?','&','%','$','!']
        numList = ['0','1','2','3','4','5','6','7','8','9']
        specialCheck = False
        numCheck = False
        containUpper = False
        containLower = False
        noSpace = False

        forbiddenChar = '|' # Forbidden char as it is used to split in dict
        try: 
            checkInput = input(question)
            checkInput.strip()  # Removes any spaces

            for char in specialCharList:
                # If special char is found and it does not contain and forbidden char and is between 4 to 20 char or input = 0
                if checkInput.find(char) != -1 and checkInput.find(forbiddenChar) == -1 and len(checkInput) >= 4 and len(checkInput) <= 20 or checkInput == '0':
                    specialCheck = True

            # Ensures that there is a number in the pwd
            for num in numList:
                if checkInput.find(num) or checkInput == '0':
                    numCheck = True

            # Ensure that there is no space 
            for char in checkInput:
                if char != ' ':
                    noSpace = True

            # Ensure that there is a upper case char in pwd
            for char in checkInput:
                if char.isupper() or checkInput == '0':
                    containUpper = True  

            # Ensure that there is a lower case char in pwd
            for char in checkInput:
                if char.islower() or checkInput == '0':
                    containLower = True

            if specialCheck and numCheck and containUpper and containLower and noSpace == True:
                return checkInput    # If all checks are true, then return the input
            else:                
                # For any errors during password Check
                print('\33[41m' + f'Error! Please ensure that password contains at least one special char from {specialCharList}' + '\33[0m')
                print('\33[41m' + 'AND does not contain \'|\'' + '\33[0m')
                print('\33[41m' + 'AND contains 1 number' + '\33[0m')
                print('\33[41m' + 'AND contains one uppercase and one lowercase char' + '\33[0m')
                print('\33[41m' + 'AND must be between 4 and 20 characters with no spaces in it' + '\33[0m' + '\n')

        except EOFError:            # error for when user enters ctrl + z
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')
        except KeyboardInterrupt:   # Error for when user enters ctrl + c
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')
            

# This function prompts the user to enter a valid userID and its email for them to reset password
# The argument of the function takes in the userDict that stores the account information from userid_pswd.txt
def resetPwd(dictionary):
    while True:
        checkUserID = stringValidation(question='\n'+ '\33[32m' + '\33[4m' + 'Please Enter Your User ID' + '\33[0m'  +'\n[0] Back to login page\n>>> ')

        if checkUserID == '0':
            break
        
        # Check for valid user ID
        else: 
            checkUserID = 'UserID: ' + checkUserID.strip() + ' '

            # Checks if userID entered by user is valid + store account email into accountEmail
            for key in dictionary:
                if checkUserID == dictionary[key][0]:
                    correctUserID = True
                    accountEmail = dictionary[key][2]  # Storing of email tied to account to accountEmail
                    dictKey = key                      # Storing of dict key for writing later
                    break
                else: 
                    correctUserID = False

            if correctUserID == True:

                email = stringValidation(question='\n'+ '\33[32m' + '\33[4m' + 'Please Enter Your Email' + '\33[0m'  +'\n[0] Back to login page\n>>> ')
                email = ' Email: ' + email.strip() 

                if email == ' Email: 0':  # If user enters 0 to quit,  email = ' Email: ' + '0'
                    break
                # If email is valid allow user to reset password
                elif email == accountEmail: 
                    input('\n'+'\33[42m' + 'Success! To Reset Password, Press Enter to continue...' + '\33[0m' + '\n')
                    newPwd = pwdCheck(question='\n'+ '\33[32m' + '\33[4m' + 'Please Enter new password'+'\33[0m'+'\n[0] Back to Enter User ID\n>>> ')
                   
                    # If user choses not to quit, reprompt to re-enter password
                    if newPwd != '0':
                        checkPwd = stringValidation('\n'+ '\33[32m'+ '\33[4m' + 'Please re-enter new password'+'\33[0m'+'\n[0] Back to Enter User ID\n>>> ')

                        if checkPwd != '0' and checkPwd == newPwd:
                            
                            # Reformatting of new password
                            dictionary[dictKey][1] = ' pwd: wla' + newPwd[::-1] 
                            
                            fn = open(userID_pwdTxt,'w') # Write mode
                            # Writing of old account details stored onto old txt file + new password
                            for key in dictionary:       
                                    # Writes UserID | password | email to userid_pswd.txt
                                    fn.write(dictionary[key][0] + '|' + dictionary[key][1] + '|' + dictionary[key][2] + '\n')
                            fn.close()

                            input('\33[42m' + '\nPassword Successfully Changed! Press enter to continue...' + '\33[0m' + '\n')
                            # break out of while True loop to go back to login Menu
                            break
                        
                        # 2 passwords that user entered did not match
                        else:
                            if checkPwd != '0':
                                print('\n'  + '\33[41m' + 'Error! Passwords do not match. Please re-enter information again' + '\33[0m' + '\n')
                        
                # Email does not match account's email
                else:
                    print('\n'  + '\33[41m' + 'Error! Email is invalid! Please re-enter information again' + '\33[0m' + '\n')

            # Error message for when userID entered does not exists in userid_pswd.txt        
            else: 
                print('\n'  + '\33[41m' + 'Error! UserID is invalid! Please re-enter UserID again' + '\33[0m' + '\n')


# This function prompts user for login before leading them to main menu
def loginMenu():
    while True: 
        try: 
            # use time module to get seconds since 1970 and convert into Local time with .ctime
            currentTime = time.ctime(time.time())

            # Creates a dict containing user with their respective passwords from userid_pswd.txt
            userDict = readFile(userID_pwdTxt)
            if userDict == {}:
                emptyUserDict = True
            else:
                emptyUserDict = False

            loginUserMenu = '\n==============================================\n' + '\33[32m' + '\t\t' + '\33[4m'+ '\ Login Page /' + '\33[0m'
            loginUserMenu += f'\n\n[1] Login\n[2] Forget Password\n[0] Quit\n\nCurrent Time: {currentTime}\n'
            loginUserMenu += '\n==============================================\n>>> '
                
            chosenOption = validationRange(start=0,end=2,question=loginUserMenu)    

            # Quit
            if chosenOption == 0:
                print('\33[91m' + 'Terminating Programme...' + '\33[0m')
                print('\33[32m' + 'Programme Terminated' + '\33[0m' + '\n')
                break
            
            # Login using userID and password
            if chosenOption == 1 and emptyUserDict == False:
                userID = loginUser(dict = userDict)
                # userID == None when there user exits loginUser function without entering correct userID and password
                if userID != None:
                    # Go to mainMenu with user selected userID after successful login
                    mainMenu(userID)

            # Reset Password
            elif chosenOption == 2 and emptyUserDict == False:
                resetPwd(dictionary=userDict)
            
            # Error for when there is no users in userid_pswd.txt
            elif emptyUserDict == True:
                print('\n' + '\33[41m' + 'Error! No users in database! Please contact administrators for help'+'\33[0m' +'\n' )
        
        except EOFError:            # error for when user enters ctrl + z
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')
        except KeyboardInterrupt:   # Error for when user enters ctrl + c
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')

loginMenu()