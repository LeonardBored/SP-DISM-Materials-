# StudentID:    P2006264
# Name:	        Soh Kai Meng Leonard
# Class:		DISM/FT/1B/05 
# Assessment:	CA1 
# 
# Script name:	admin.py
# 
# Purpose:	Purpose of admin script is to edit / configure the quiz
#
# In User settings, it allows admin to view user list,register users, delete users, reset user password and delete a user attempt from quiz results
# In Setup Question Pool, it allows admin to view question list, add question, delete question and edit question property
# In editing question property, admin chooses a selected question from question pool and is able to change question title, edit option, change marks for question and randomize options
# In Quiz Settings, admin is able to edit the settings for quiz e.g. time of quiz, question for quiz and attempts for quiz
# Lastly, admin is able to generate a quiz report. The quiz report is based on the number of questions tested in the quiz
# After picking the num of questions the quiz tested, it then gives a statistical report based on all atttempts that had that num of question tested
#
#
# Usage syntax:	Run with play button
# 
# Input file:	
#
# './Text_Files/question_pool.txt'
# './Text_Files/quiz_setting.txt'
# './Text_Files/userid_pswd.txt'
# './Text_Files/quiz_results.csv'
#  
# Output file:	
#
# './Text_Files/question_pool.txt'
# './Text_Files/quiz_setting.txt'
# './Text_Files/userid_pswd.txt'
# './Text_Files/quiz_results.csv'
#
# Python ver:	Python 3
#
# Reference:
#   (a) statistics — Mathematical statistics functions
#       https://docs.python.org/3/library/statistics.html 
#       accessed on 21 Nov 2021'
#
#   (b) Python CSV
#       https://www.programiz.com/python-programming/csv
#       accessed on 19 Nov 2021
#
#   (c) Python Random shuffle() Method 
#       https://www.w3schools.com/python/ref_random_shuffle.asp
#       accessed on 15 Nov 2021
#	
# Module : 
#
# Random Module
# CSV Module
# Statistics module
#
# Known issues:	eg. no validation of input value
#
# ****************************** User-defined functions ***************************
# Describe the purpose of user-defined functions, parameters and return values

# This function checks for userInput and only accepts if userInput is within the range specified
# The argument of this function takes in the start and end integer values and finally the question being asked
# The function returns a valid integer number between the range specified in the argument
def validationRange(start,end,question): 
    while True:
        try:
            checkInput = int(input(question))
            if checkInput < start or checkInput > end:
                raise OverflowError
            else:
                return checkInput
        except OverflowError:   # for out of range
            print('\33[41m' +f'Out of range! Please enter an integer number between {start} and {end}'+ '\33[0m' +'\n')
        
        except ValueError:      # for not int number input 
            print('\33[41m'+ f'Invalid, not int. Please enter an integer number between {start} and {end}'+'\33[0m' + '\n')

        except EOFError:        # error for when user enters ctrl + z
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')
        except KeyboardInterrupt:   # Error for when user enters ctrl + c
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')


# This function checks for any illegal char used in user inputs and rejects it if it is found. 
# The argument of this function takes in the question being asked
# The function returns a valid string that does not contain illegal char in the specialCharList
def stringValidation(question):
    specialCharList = ['~','`','`','\ ','|']
    while True: 
        try:
            counter = 0   
            checkInput = input(question)
            checkInput = checkInput.strip() # Removes spaces
            if checkInput == '':
                counter += 1
                print('\33[41m' + 'Empty input! Please re-enter again' + '\33[0m' + '\n')

                
            for char in specialCharList:
                # Ensure user input no special char
                if checkInput.find(char) != -1:   # If input contains special char : reject it
                    print('\33[41m' + f'Invalid char {char} entered! Please re-enter again' + '\33[0m' + '\n')
                    counter += 1
                    break

            if counter == 0:                
                return checkInput   # Validated after no special char in input
                
        except EOFError:            # error for when user enters ctrl + z
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')
        except KeyboardInterrupt:   # Error for when user enters ctrl + c
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')

# This function creates a dictionary. The number of key = the number of lines of the given txt file
# In each key, there will be a list of items, made by .split('|')
# The argument of this function takes in a textfile's pathway
# It returns a dictionary created based on the data stored in the text file
def readFile(txtFile):
    dict = {}
    with open(txtFile,'r') as fn:       # Opens the given text file in read mode
        for i, line in enumerate(fn):   # For each line in the given txt file
            line = line.strip()         # Removes any spaces + '\n'
            dict[f'{i + 1}'] = line.split('|')    # Creates a list with the seperator '|' seperating each element
    
    # Checks for any empty list that were stored in dictionary keys
    emptyKeyList = []
    for key in dict:
        if dict[key] == ['']:
            emptyKeyList.append(key)
    
    # Deletes dict key that contains empty list as it is invalid
    for key in emptyKeyList:    
        del dict[key]
        
    return dict   # Returns the created dictionary

# This function takes in a list and question as parameters and ensures that user Input is an element in the given list
# The argument of this function takes in a list and the question being asked
# It returns a valid input that is inside the specified list in the argument
def listRangeValidation(list,question):
    while True: 
        try: 
            checkInput = input(question)
            checkInput.lower()              # Lowercase the input
            for char in list:
                if checkInput == char:      # if input is found within the list
                    return checkInput       # Returns input
            print('\33[41m' + f'Please re-enter a option from {list}'+ '\33[0m' +'\n')

        except EOFError:            # error for when user enters ctrl + z
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')
        except KeyboardInterrupt:   # Error for when user enters ctrl + c
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')
            
# This function prints all the questions available in question_pool.txt and returns the last index of the last question
# The argument of this function takes in the question pool dict
# It returns the question index where it could be found using the key of the dictionary
def printQuestions(dict):
    questionsIndex = 1
    print('\33[32m' + '\n*** Current Question List ***' + '\33[0m')
    for key in dict:
        print('\n' +'\33[32m' +f'Question {questionsIndex}: ' + '\33[0m' + f'{dict[key][0]} ({dict[key][6]}m) | Correct Answer: {dict[key][5]}' )    # Printing of question + answer
        for i in range(4):   # Printing of options 
            print(f'{dict[key][i+1]}')
        questionsIndex += 1  
    
    return questionsIndex 

# This function prints the selected question in the questionPool dict
# The argument of this function is the key of the selected question, its question pool dictionary
def printSelectedQuestion(selectedQuestion,dictionary):
    print('\n---------------------------------------------\n')
    print('\n'+ '\33[32m' +f'Question {selectedQuestion}: ' + '\33[0m' f'{dictionary[str(selectedQuestion)][0]} ({dictionary[str(selectedQuestion)][6]}m) | Correct Answer: {dictionary[str(selectedQuestion)][5]}')
    for i in range(4):   # Printing of options 
        print(f'{dictionary[str(selectedQuestion)][i+1]}')
    
    print('\n---------------------------------------------\n')

# This function will write onto the question_pool.txt given the updated question dictionary
# The argument of this function takes in the updated question pool dict
def writeQuestion(dict): 
    fn = open(questionPoolTxt,'w') # write mode
    for key in dict :                                # for each key in question dict
        for question in range(6):                    # Write out the element of each question except marks
          fn.write(dict[key][question] + '|') 

        fn.write(f'{dict[key][6]}\n') # Writes marks of the question has without '|' and a line feed for new line
    fn.close()

#
# ******************************* Main program ***********************************


# Insert clear description to facilitate maintenance of script in the future

import random
import csv
import statistics

# Global variabes that contains the pathway to individual text files
questionPoolTxt = './Text_Files/question_pool.txt'
quizSettingTxt = './Text_Files/quiz_setting.txt'
userID_pwdTxt = './Text_Files/userid_pswd.txt'
resultsCsv = './Text_Files/quiz_results.csv'


# This function promopts the user and allows them to create a new question and update accordingly to the question_pool.txt    
# The argument of this function takes in the question pool dict
def addQuestion(dict): 
    while True: 
            newQuestionList = []
            optionNumbering = ['a','b','c','d']
            addQuestionStr = '\33[32m' + '\n*** Add Question ***\n' + '\33[0m' + 'Please enter a new Question\n[0] Back\n>>> '
            
            newQuestion = stringValidation(question=addQuestionStr)
            if newQuestion == '0':
                newQuestionList.clear()
                break
            
            newQuestionList.append(newQuestion) # Adds Question to list
            
            # Loops 4 times for options a - d. when user inputs 0, it will break out of loop
            for i in range(4):
                newOption = stringValidation(question=f'\nPlease enter question option {optionNumbering[i]})\n[0] Cancel\n>>> ')
                if newOption == '0':
                    newQuestionList.clear()   # Removes all elements in list
                    break
                newQuestionList.append(f'{optionNumbering[i]}) {newOption}') # Adds option to List
                
            if newOption != '0':            # Option == 0 is for cancel selection
                print('\33[32m' + '\n*** NEW QUESTION ***' + '\33[0m')
                for i in newQuestionList:   # Prints new question + options
                    print(i)    
                # listRangeValidation ensures that newOption will only contain a,b,c,d
                newOption = listRangeValidation(list=optionNumbering,question='\nPlease enter the correct option from (a to d)\n>>> ')
                newQuestionList.append(newOption)

                marks = validationRange(start=1,end=5,question='\nPlease enter the amount of marks (1 to 5 marks) for this question\n>>> ')
                newQuestionList.append(marks)

                # Prints updated question with correct answer selected
                print(f'\nNew Question: \n{newQuestionList[0]} ({marks}m) | Correct Option: {newQuestionList[5]}') 
                for i in range(4):   # Prints options
                    print(newQuestionList[i+1])

                chosenOption = validationRange(start=0,end=1,question= '\n' + '\33[41m' + '*** CONFIRMATION : Add new Question? ***' + '\33[0m' + '\n[1] YES \t [0] NO\n >>> ')
                
                if chosenOption == 0:
                    newQuestionList.clear()  # Clears list if user decides not to confirm
                else: 
                    questionStr = ''
                    for i in range(5):      # Loops through from index 0 to the last option, d)
                        questionStr += newQuestionList[i] + ' |'  # Make a str for the new Question in the format : question | options | answer
                    
                    # Adds correct answer and the amount of marks the question is at the end of the string
                    questionStr += newQuestionList[5] + ')|' + str(newQuestionList[-1])     
 
                    fn = open(questionPoolTxt,'w') # write mode
                    for key in dict :                             # for each key in question dict
                        for question in range(6):                 # Write out the element of each question except marks 
                            fn.write(dict[key][question] + '|') 
                        fn.write(f'{dict[key][6]}\n')             # Writes marks of the question has without '|' and start new line
                    
                    fn.write(questionStr)               # Finally, Write the new question onto the file at the end
                    fn.close()
                    input('\33[42m' + '\nSuccess! Press enter to continue...' + '\33[0m' + '\n')
                    break

# This function allows admin to delete questions in question List
# The argument of this function takes in the question pool dict
def deleteQuestion(dict):
    while True: 
        lastIndex = printQuestions(dict)
        chosenOption = validationRange(start=0, end=lastIndex-1, question='\nEnter the index for Question to delete\n[0]Back\n>>> ') # range is 0 to index of last question
        if chosenOption == 0:
            break
        else: 
            confirmDelete = validationRange(start=0, end=1, question='\n' + '\33[41m' + '*** CONFIRMATION : Delete Question? ***' + '\33[0m' + '\n[1] Yes\t[0] No (Back)\n>>> ')
            
            if confirmDelete == 1:
                # Deleting of questions
                del dict[str(chosenOption)]    # This deletes the key which contain the chosen question in the dict
                writeQuestion(dict)            # Updates txt file
                input('\33[42m' + '\nSuccess! Press enter to continue...' + '\33[0m' + '\n')
                break

# This function allows admin to randomize all questions's options one by one in question list
# Admin will be prompted each question and can choose to stick to old options or new randomized options
# The argument of the function takes in the question pool dictionary
def randomAllOption(dict):
    checkOption = validationRange(start=0,end=1,question='\nRandomise option arrangement? (1 by 1)\n[1] YES \t [0] NO (Back)\n>>> ')
    # user presses 1 for confirmation to randomize option arrangement
    if checkOption == 1:
        for key in dict:
            oldOptionList = dict[key][1:6]  # Set oldOptionList a list with all options from a to d + answer
            optionList = dict[key][1:5]     # set optionList as a list with all options from a to d

            optionStrList = []
            correctOption = ''
            
            print('\n*** Old Question ***')
            printSelectedQuestion(selectedQuestion = key,dictionary = dict)

            # For each option among the 4 options form a) to d), find the correct answer and store in a str
            for option in optionList:                 
                if option.find(dict[key][5]) != -1:
                    optionStrList = option.split()     # append each word into a list
                    optionStrList.pop(0)               # Removes a) top d)

                    # Formatting of correct answers without a) to d)
                    for char in optionStrList :
                        correctOption += char + ' ' 

            # Randomly shuffles the list
            random.shuffle(optionList)

            # Removes the optionNumbering for each option and replace with a) to d)
            for i , numbering in enumerate(['a','b','c','d']):
                optionStrList = optionList[i].split()        # append each word into a list
                optionStrList.pop(0)                         # Removes a) to d) it was initialized with
                newOption = numbering + ') '                 # Adds a) to d) respectively to match the order
                for char in optionStrList:
                    newOption += char + ' '                  # Format the option as a) option....
                dict[key][i+1] = newOption     # update new option into dict

            # Find the correct answer's option Numbering using plain text answer
            for option in dict[key][1:5]:      # For each option in dict
                if option.find(correctOption) != -1:         # Find the correctOption with just the substring of the plain text option without its numbering a) to d)
                    dict[key][5] = option[0:2] # Adds the appropriate option numbering, a) to d) to inidicate the new correct answer

            #Print question with randomized options
            print('\n*** Questions with new randomized options ***')
            printSelectedQuestion(selectedQuestion=key,dictionary=dict)

            checkOption = validationRange(start=0,end=2,question='\n' + '\33[41m'+'*** CONFIRMATION *** : Accept new question?'+'\33[0m' +'\n\n[1] YES \t [2] NO (Stick to Old question)\n[0] Quit\n>>> ')
            
            # Breaks out of for loop as user decides to quit
            if checkOption == 0:
                break      

            # If user confirms new question with randomized options
            elif checkOption == 1:
                writeQuestion(dict)
                input('\33[42m' + '\nSuccess, Question changed with new options! Press enter to continue...' + '\33[0m' + '\n')
                
            # If user cancels, assign options + answer back to old value
            else :
                # Assign options back to old values
                for i in range(4):   
                    dict[key][i+1] = oldOptionList[i]

                dict[key][5] = oldOptionList[4]   # Assign answer back to old value     




# This function allows user to navigate on what they want to do for different settings affecting the questions            
def setupQuestion():

    # formatting of menu prompt for setup question
    setupQuestionMenu = '\n---------------------------------------------\n' + '\33[32m' + '\t ' + '\33[4m'+ '{ Setup Quiz Questions }' + '\33[0m'
    setupQuestionMenu += '\n\n[1] View Question List\n[2] Add Question\n[3] Delete Question\n[4] Edit Question Property\n[5] Randomize all Question Options\n[0] Back'
    setupQuestionMenu += '\n\n---------------------------------------------\n>>> '

    while True:
        # Creats a question pool dict and read file
        questionDict = readFile(questionPoolTxt)
        if questionDict == {}:      # Ensures that question dictionary is not empty
            emptyQuestionPool = True 
        else: 
            emptyQuestionPool = False
        
        chosenOption = validationRange(start=0,end=5,question=setupQuestionMenu)
        if chosenOption == 0:           # Exits setupQuestion() to go back to main menu
            break

        elif chosenOption == 1 and emptyQuestionPool == False:  # Viewing of question List
            printQuestions(dict = questionDict)
                
        elif chosenOption == 2:                                 # Addition of questions, do not need any questions in question pool
            addQuestion(dict = questionDict)
         
        elif chosenOption == 3 and emptyQuestionPool == False:  # Delete Questions
            deleteQuestion(dict = questionDict)
    
        elif chosenOption == 4 and emptyQuestionPool == False:  # Editing of question properties
            editQuestionMenu(dict = questionDict)

        elif chosenOption == 5 and emptyQuestionPool == False:  # Randomize of all questions (one by one)
            randomAllOption(dict = questionDict)

        elif emptyQuestionPool == True:
            print('\33[41m' + 'Empty Question Pool! Please make a question pool before deleting any questions' + '\33[0m' + '\n')



# This function allows admin to edit question titles of the selected question
# The argument of this function takes in the selected question and the question pool dict
def editQuestionTitle(chosenOption,dict):
    newQuestion = stringValidation(question=f'\nOriginal Question Title: {dict[str(chosenOption)][0]}\nEnter new Question Title\n>>> ')

    # Below Prints the updated Question 
    print(f'\nQuestion {chosenOption}. [{newQuestion}]' + '\33[41m' + '(New!)' + '\33[0m' + f'({dict[str(chosenOption)][6]}m)| Correct Answer: {dict[str(chosenOption)][5]}')    
    for i in range(4):   # Printing of options 
        print(f'{dict[str(chosenOption)][i+1]}')
    # Confirms to change question

    checkOption = validationRange(start=0,end=1,question='\n' + '\33[41m' + '*** CONFIRMATION : change to new edited question? ***'+ '\33[0m' +'\n\n[1] YES \t [0] NO (back)\n>>> ')
    if checkOption == 1: 
        dict[str(chosenOption)][0] = newQuestion   # Changes to new question in question dict
        writeQuestion(dict)                        # Updates txt file
        input('\33[42m' + '\nSuccess! Press enter to continue...' + '\33[0m' + '\n')

# This function allows admin to edit and change the options
# It also allows the admin to change the correct answer (optional)
# The argument of this function takes in the selected question and the question pool dict
def editOption(chosenOption,dict):
    optionNumbering = ['a','b','c','d','0']
    checkOption = listRangeValidation(list=optionNumbering,question=f'\n{dict[str(chosenOption)][1:5]}\nPlease choose an option to edit\n[0] Cancel\n>>> ')
    
    # if user never presses 0 for cancel
    if checkOption != '0':
        # finds index of checkOption in optionNumbering list + store old value of option in oldOption
        indexOfOption = optionNumbering.index(checkOption) + 1  # Gives the index of the option selected and +1 as index 0 in list in dict contains question
        oldOption = dict[str(chosenOption)][indexOfOption]      # Stores old value of option selected
        correctOption = dict[str(chosenOption)][5]              # Stores the correct option's numbering such as a) to d)   
        oldCorrectOption = correctOption                        # Stores old correct option
        
        # Ask to enter new option given the old option
        newOption = stringValidation(question=f'\nOriginal option: {oldOption}\nEnter new option\n>>> ')
        dict[str(chosenOption)][indexOfOption] = checkOption + ') ' + newOption + ' (New!)' # Sets selected option to new option user has inputed
        
        checkOption = validationRange(start=0,end=1,question='\33[41m' +'\nChange correct answer?' + '\33[0m' + '\n[1] YES \t[0] NO\n>>> ')
        
        # if user chooses to change correct answer
        if checkOption == 1:
            # Prints out updated question and asks for new correct answer between a-d
            checkOption = listRangeValidation(list=optionNumbering,question=f'\nQuestion:{dict[str(chosenOption)][0]}\n\nOptions:{dict[str(chosenOption)][1:5]}\n\nOriginal Correct Answer: {dict[str(chosenOption)][5]}\n\nChoose a new correct answer\n[0] Cancel\n>>> ')
            #If user never input 0 for cancel
            if checkOption != '0':
                correctOption = checkOption + ')'  # Adds a ) to the new correctOption str
                dict[str(chosenOption)][5] = correctOption + '\33[41m' + '(New!)' + '\33[0m'
        
        #printing of question with new option
        printSelectedQuestion(selectedQuestion=chosenOption,dictionary=dict)
        
        # Confirm if user wants to change option
        checkOption = validationRange(start=0,end=1,question='\n' + '\33[41m' + '*** CONFIRMATION : save new edited option? ***' + '\33[0m' '\n\n[1] YES \t [0] NO (back)\n>>> ')
        # If user confirms to change option
        if checkOption == 1: 
            # Remove the (New!) added previously OR Take in the intialized correctOption that remained unchanged if user did not change correct option
            dict[str(chosenOption)][5] = correctOption 
            # Remove the (New!) added previously
            dict[str(chosenOption)][indexOfOption] = optionNumbering[indexOfOption - 1] + ') ' + newOption 
            writeQuestion(dict)
            input('\33[42m' + '\nSuccess! Press enter to continue...' + '\33[0m' + '\n')
        # User presses 0 at end to cancel all
        else: 
            # Reset to old option if user presses 0 to cancel changing of options
            dict[str(chosenOption)][indexOfOption] = oldOption # Changes back to old option
            dict[str(chosenOption)][5] = oldCorrectOption # Changes back to old answer


# This function changes the mark allocation to the selected question from 1 to 5
# The argument of this function takes in the selected question and the question pool dict
def changeMarks(chosenOption,dict): 
    newMarks = validationRange(start=0,end=5,question=f'Old Marks: {dict[str(chosenOption)][6]}m\n\nPlease Enter new marks from 1-5\n[0] Cancel (Back)\n>>> ')
    
    if newMarks != 0:
        oldMarks = dict[str(chosenOption)][6]                         # Stores old marks
        dict[str(chosenOption)][6] = str(newMarks) + '\33[41m' + '[New!]' + '\33[0m' # formatting of new Marks for printing
        
        # Prints updated question with new marks
        printSelectedQuestion(selectedQuestion=chosenOption,dictionary=dict)

        # Resetting formatting for newMarks in dict
        dict[str(chosenOption)][6] = str(newMarks)

        # Confirmation for changing of marks
        checkOption = validationRange(start=0,end=1,question='\n' + '\33[41m' + '*** CONFIRMATION : Change to new marks? ***'+'\33[0m' '\n\n[1] YES \t [0] NO (Back)\n>>> ')

        # If user input 1, to confirm changing of marks
        if checkOption != 0:
            writeQuestion(dict)        # Update to text file
            input('\33[42m' + '\nSuccess! Press enter to continue...' + '\33[0m' + '\n')
        # For user input 0, cancel of marks
        else :
            # Reset back to old marks
            dict[str(chosenOption)][6] = oldMarks

# This function randomizes the options in the question specified by the user
# The argument of this function takes in the selected question and the question pool dict
def randomOption(chosenOption,dict): 
    checkOption = validationRange(start=0,end=1,question='Randomise option arrangement?\n\n[1] YES \t [0] NO (Back)\n>>> ')
    # user presses 1 for confirmation to randomize option arrangement
    if checkOption == 1:
        oldOptionList = dict[str(chosenOption)][1:6]  # Set oldOptionList a list with all options from a to d + answer
        optionList = dict[str(chosenOption)][1:5]     # set optionList as a list with all options from a to d

        optionStrList = []
        correctOption = ''

        # For each option among the 4 options form a) to d), find the correct answer and store in a str
        for option in optionList:                 
            if option.find(dict[str(chosenOption)][5]) != -1:
                optionStrList = option.split()     # append each word into a list
                optionStrList.pop(0)               # Removes a) top d)

                # Formatting of correct answers without a) to d)
                for char in optionStrList :
                    correctOption += char + ' ' 

        # Randomly shuffles the list
        random.shuffle(optionList)

        # Removes the optionNumbering for each option and replace with a) to d)
        for i , numbering in enumerate(['a','b','c','d']):
            optionStrList = optionList[i].split()        # append each word into a list
            optionStrList.pop(0)                         # Removes a) to d) it was initialized with
            newOption = numbering + ') '                 # Adds a) to d) respectively to match the order
            for char in optionStrList:
                newOption += char + ' '                  # Format the option as a) option....
            dict[str(chosenOption)][i+1] = newOption     # update new option into dict

        # Find the correct answer's option Numbering using plain text answer
        for option in dict[str(chosenOption)][1:5]:      # For each option in dict
            if option.find(correctOption) != -1:         # Find the correctOption with just the substring of the plain text option without its numbering a) to d)
                dict[str(chosenOption)][5] = option[0:2] # Adds the appropriate option numbering, a) to d) to inidicate the new correct answer

        #Print question with randomized options
        print('\n*** Questions with new randomized options ***\n')
        printSelectedQuestion(selectedQuestion=chosenOption,dictionary=dict)

        checkOption = validationRange(start=0,end=1,question='\n' + '\33[41m'+'*** CONFIRMATION *** : Accept new question?'+'\33[0m' +'\n\n[1] YES \t [0] NO (Back)\n>>> ')
        
        # If user confirms new question with randomized options
        if checkOption == 1:
            writeQuestion(dict)
            input('\33[42m' + '\nSuccess! Press enter to continue...' + '\33[0m' + '\n')
            
        # If user cancels, assign options + answer back to old value
        else :
            # Assign options back to old values
            for i in range(4):   
                dict[str(chosenOption)][i+1] = oldOptionList[i]

            dict[str(chosenOption)][5] = oldOptionList[4]   # Assign answer back to old value     

# This function allows user to edit question properties
# The argument of this function takes in the question pool dict
def editQuestionMenu(dict):
    while True:
        lastIndex = printQuestions(dict)
        # range is 0 to index of last question
        chosenOption = validationRange(start=0, end=lastIndex-1, question=f'\nEnter the index for Question to edit (1 to {lastIndex-1})\n[0]Back\n>>> ') 
        if chosenOption == 0: 
            break
        # Prints the selected question with its options 
        while True:
            printSelectedQuestion(selectedQuestion=chosenOption , dictionary = dict)

            checkOption = validationRange(start=0,end=4,question='\n[1] Edit Question Title\n[2] Edit Option\n[3] Change Marks for Question\n[4] Randomize Options\n[0] Back\n>>> ')
            
            # Editing Question (title)
            if checkOption == 1:  
                editQuestionTitle(chosenOption,dict)

            # Editing Question options
            elif checkOption == 2:  
                editOption(chosenOption,dict)

            # Change marks for question
            elif checkOption == 3:     
                changeMarks(chosenOption,dict)

            # Randomise option arrangement
            elif checkOption == 4:  
                randomOption(chosenOption,dict)
            
            elif checkOption == 0: # Exits loop
                break

# This function asks for user input for selected quiz setting and updates it to quiz_setting.txt
# The argument of this function takes in the quizSetting Dict, its selected quiz setting (key),its question and an optional string for additional formatting
def writeSetting(dict,key,checkQuestion): 
    # Validation for input for it to be an integer and for number of questions for quiz
    while True:
        counter = 0
        try:
            checkInput = int(input(checkQuestion)) # try to int a string
            if key == '2':
                with open(questionPoolTxt,'r') as fn:
                    for line in fn:
                        counter += 1  # Counts the number of question in question pool

                    if checkInput <= counter and checkInput >= 0:
                        break
                    else :
                        print('\33[41m'+f'Questions in question pool: {counter}.\nError! Please enter a number from 0 to {counter}.'+'\33[0m' + '\n')

            elif checkInput >= 0:
                break  # For normal inputs if they are >= 0
            
            elif checkInput < 0:
                print('\33[41m'+f'error! Please enter an integer greater than or equal to 0'+'\33[0m' + '\n')
        # if user key in a string, reject it and prompt question again
        except ValueError:
            print('\33[41m' + 'Invalid char entered! Please re-enter an integer number!' + '\33[0m' + '\n')
        except EOFError:            # error for when user enters ctrl + z
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')
        except KeyboardInterrupt:   # Error for when user enters ctrl + c
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')


    # Convert int to str
    checkOption = str(checkInput)
    # Ensure that user does not cancel
    if checkOption != '0':
        # Will update the settings dictionary according to the key given in the parameter
        dict[key][1] = checkOption
        
        fn = open(quizSettingTxt,'w') # Write mode
        for key in dict:                                  # for each key in dict
            fn.write(dict[key][0] + '|' + dict[key][1])   # Write settings onto txt file
            fn.write('\n')                                # Add line feed for new line
        fn.close()
        input('\33[42m' + '\nSuccess! Press enter to continue...' + '\33[0m' + '\n')

# This function allows user to change properties of quiz_settings.txt to change quiz settings
def quizSetting():
    while True:
        # Creats a dict of quiz settings by reading file quiz_setting.txt
        settingsDict = readFile(quizSettingTxt)

        if settingsDict == {}:   # If dictionary is empty,
            settingsDict['1'] = ['Time for quiz: ','empty']
            settingsDict['2'] = ['Number of questions for quiz: ','empty']
            settingsDict['3'] = ['Maximum number of attempts for quiz: ','empty']
            fn = open(quizSettingTxt,'w') # Write mode
            for key in settingsDict:                                  # for each key in dict
                fn.write(settingsDict[key][0] + '|' + settingsDict[key][1])   # Write settings onto txt file
                fn.write('\n')                                # Add line feed for new line
            fn.close()

        # Adds a min after time for printing
        oldTime = settingsDict['1'][1]
        settingsDict['1'][1] = settingsDict['1'][1] + ' min'


        # formatting of current quiz settings to print to user
        quizSettingsMenu = '\n---------------------------------------------\n'+ '\33[32m' +  '\t' + '\33[4m' + '{ Current Quiz Settings }' + '\33[0m' '\n\n'

        for setting in settingsDict:
            # '\033[91m' is for red color text and to end red text is '\033[0m'
            quizSettingsMenu += settingsDict[setting][0] + '\033[91m' + '\33[4m' + settingsDict[setting][1] + '\033[0m' + '\n'
        
        quizSettingsMenu += '\n---------------------------------------------\n'
        quizSettingsMenu += '[1] Edit Time for Quiz\n[2] Edit Number of Questions for Quiz\n[3] Edit Maximum Number of attempts for Quiz\n[0] Back\n>>> '
        
        # Resesting of time setting by setting it back to old one
        settingsDict['1'][1] = oldTime

        chosenOption = validationRange(start=0,end=3,question=quizSettingsMenu)

        if chosenOption == 0:
            break
        # Editing of time for quiz
        elif chosenOption == 1:
            writeSetting(dict = settingsDict,key='1',checkQuestion=f'\nCurrent Time setting : {settingsDict[str(1)][1]}\nPlease Enter new time (in minutes)\n[0] Cancel (Back)\n>>> ')
        # Editing Number of questions in quiz
        elif chosenOption == 2:
            writeSetting(dict=settingsDict,key='2',checkQuestion=f'\nCurrent Number of questions for quiz : {settingsDict[str(2)][1]}\nPlease Enter new number of questions\n[0] Cancel (Back)\n>>> ')

        # Editing Number of attempts for quiz
        elif chosenOption == 3:
            writeSetting(dict=settingsDict,key='3',checkQuestion=f'\nCurrent Attempts for quiz : {settingsDict[str(3)][1]}\nPlease Enter new number of attempts\n[0] Cancel(Back)\n>>> ')

# This function ensures that password contains special char + minimum length of 8
# The argument of this function takes in the question being used to prompt user
def pwdCheck(question):
    while True: 
        specialCharList = ['@','#','?','&','%','$','!']
        numList = ['0','1','2','3','4','5','6','7','8','9']
        specialCheck = False
        numCheck = False
        containUpper = False
        containLower = False
        noSpace = False

        forbiddenChar = '|' # Forbidden char as it is used to split in dict
        try: 
            checkInput = input(question)
            checkInput.strip()  # Removes any spaces

            for char in specialCharList:
                # If special char is found and it does not contain and forbidden char and is between 4 to 20 char or input = 0
                if checkInput.find(char) != -1 and checkInput.find(forbiddenChar) == -1 and len(checkInput) >= 4 and len(checkInput) <= 20 or checkInput == '0':
                    specialCheck = True

            # Ensures that there is a number in the pwd
            for num in numList:
                if checkInput.find(num) or checkInput == '0':
                    numCheck = True

            # Ensure that there is no space 
            for char in checkInput:
                if char != ' ':
                    noSpace = True

            # Ensure that there is a upper case char in pwd
            for char in checkInput:
                if char.isupper() or checkInput == '0':
                    containUpper = True  

            # Ensure that there is a lower case char in pwd
            for char in checkInput:
                if char.islower() or checkInput == '0':
                    containLower = True

            if specialCheck and numCheck and containUpper and containLower and noSpace == True:
                return checkInput    # If all checks are true, then return the input
            else:                
                # For any errors during password Check
                print('\33[41m' + f'Error! Please ensure that password contains at least one special char from {specialCharList}' + '\33[0m')
                print('\33[41m' + 'AND does not contain \'|\'' + '\33[0m')
                print('\33[41m' + 'AND contains 1 number' + '\33[0m')
                print('\33[41m' + 'AND contains one uppercase and one lowercase char' + '\33[0m')
                print('\33[41m' + 'AND must be between 4 and 20 characters with no spaces in it' + '\33[0m' + '\n')
        
        except EOFError:            # error for when user enters ctrl + z
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')
        except KeyboardInterrupt:   # Error for when user enters ctrl + c
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')

# This Function helps register users by updating user list in userid_pswd.txt
# The argument of this function takes in the users dict
def registerUser(dict):
    registerUserMenu = '\n' + '\33[32m' + '\33[4m' +'Register New User' + '\33[0m'
    while True:
        newUser = stringValidation(question=registerUserMenu + '\nPlease Enter a User ID\n[0] Cancel (Back)\n>>> ')
        accountDetails = 'UserID: ' + newUser

        # Check if there is any duplicate user ID and reject it
        duplicateUserID = False
        for account in dict:
            if dict[account][0].strip() == accountDetails:
                duplicateUserID = True
                break

        if newUser == '0':
            break
        elif len(newUser) < 5:
            print('\33[41m' + '\nPlease input a username with minimum of 5 characters' + '\33[0m' + '\n')

        # Continue to check and enter passwords
        elif duplicateUserID == False :
            # Formatting of account details for when writing onto txt file
            accountDetails = 'UserID: ' + newUser + ' | '
            # Password validation
            newPwd = pwdCheck(question= registerUserMenu + '\nPlease enter password\n[0] Cancel (Back)\n>>> ')
            # If user does not cancel
            if newPwd != '0':
                checkPwd = stringValidation(question=registerUserMenu + '\nPlease re-enter password\n[0] Cancel (Back)\n>>> ')

                # Checking whether the 2 passwords entered are the same
                if checkPwd == newPwd:
                    while True:
                        # Email account used for forgetten password in user.py
                        accountEmail = stringValidation(question=registerUserMenu+'\nPlease Enter email for account\n>>>')
                        if accountEmail.find('@') == -1:  # if @ is not found in account email, reject it
                            print('\n'+'\33[41m'+'Error! Please enter a valid email' + '\33[0m')

                        else: 
                            break # Break if '@' is found

                    confirmRegister = validationRange(start=0,end=1,question='\33[41m' + '\n*** CONFIRMATION *** : Create new account?' + '\33[0m' + '\n\n[1]Yes \t [0] NO (Back)\n>>> ')
                    # If user confirms to register, write to file
                    if confirmRegister == 1:
                        # stored password is reverse of password + adding of wla at the front of it
                        accountDetails += 'pwd: wla' + newPwd[::-1] + '| '
                        # Adds email at the end
                        accountDetails += 'Email: ' + accountEmail 
            
                        
                        fn = open(userID_pwdTxt,'w') # Write mode
                        # Writing of old account details stored onto old txt file
                        for key in dict:       
                            # Writes UserID | password | email
                            fn.write(dict[key][0] + '|' + dict[key][1] + '|' + dict[key][2] + '\n') 

                        # Writing of new account being added
                        fn.write(accountDetails)
                        fn.close()
                        input('\33[42m' + '\nSuccess! Press enter to continue...' + '\33[0m' + '\n')
                        break
                # If passwords do not match
                else:
                    if checkPwd != '0': # Error message for when passwords dont match
                        print('\33[41m' + 'Password do not match! Please re-enter information again' + '\33[0m')
        
        # Error for duplicate userIDs
        else:
            print('\33[41m'+'Error! User ID already exists! Please enter another userID' + '\33[0m' + '\n')


# This function allows the admin to delete the user selected 
# The argument of this function takes in the users dict
def deleteUser(dict):
    # creates spacing
    print('\n')
    # Printing of current user list
    for key in dict:
        print('\33[32m' +key + ' : ' + '\33[0m' + dict[key][0])

    deleteUserQuestion = f'Enter the index of the user to delete [1 to {key}]\n[0] Cancel (Back)\n>>> '
    chosenOption = validationRange(start=0,end=int(key),question=deleteUserQuestion)

    if chosenOption != 0:
        confirmDeleteQuestion = '\n'+'\33[41m' + '*** CONFIRMATION *** : Delete User?' + '\33[0m' + '\n\n[1] YES \t [0] Cancel (Back)\n>>> '
        checkOption = validationRange(start=0,end=1,question=confirmDeleteQuestion)
        if checkOption != 0:
            del dict[str(chosenOption)] # Deletes the selected userID with its pwd from dict
            
            # Update the txt file by writing updated dict to it
            fn = open(userID_pwdTxt,'w') # Write mode
            for key in dict:  # For each key in dict
                fn.write(dict[key][0] + '|' + dict[key][1] + '|' + dict[key][2] + '\n')  # Write out the userID with pwd
            fn.close()
            
            input('\33[42m' + '\nSuccess! Press enter to continue...' + '\33[0m' + '\n')

# This function allows admin to reset password of a selected user from user list
# The argument of this function takes in the users dict
def resetPwd(dict):

    # Printing of Indexes with User ID
    for key in dict:
        print('\33[32m' +key + ' : ' + '\33[0m' + dict[key][0])
    resetPwdQuestion = f'Enter the index of user to reset password [1 to {key}]\n[0] Cancel (Back)\n>>> '

    chosenOption = validationRange(start=0,end=int(key),question=resetPwdQuestion)
    
    if chosenOption != 0:
        newPwd = pwdCheck('\nPlease enter new password\n[0] Cancel (Back)\n>>> ')
        # If user does not cancel
        if newPwd != '0':
            checkPwd = stringValidation(question='\nPlease re-enter new password\n[0] Cancel (Back)\n>>> ')

            if checkPwd == newPwd:
                confirmRegister = validationRange(start=0,end=1,question='\n'+'\33[41m' + '*** CONFIRMATION *** : Create new account?' + '\33[0m' + '\n\n[1]Yes \t [0] NO (Back)\n>>> ')
                # If user confirms to register, write to file
                if confirmRegister == 1:
                    dict[str(chosenOption)][1] = ' pwd: wla' + newPwd[::-1]   # Set to new password
                    
                    fn = open(userID_pwdTxt,'w') # Write mode
                    for key in dict:  # For each key in dict
                        fn.write(dict[key][0] + '|' + dict[key][1] + '|' +dict[key][2] + '\n')  # Write out the userID with pwd
                    fn.close()

                    input('\33[42m' + '\nSuccess! Press enter to continue...' + '\33[0m' + '\n')
            # If passwords do not match
            else: 
                if checkPwd != '0': # Error message for when passwords dont match
                    print('\n'+'\33[41m' + 'Password do not match! Please re-enter information again' + '\33[0m')

# This function deletes an attempt from a user in quiz_results.csv
# This function takes in attempts stored in the quiz_result.csv 
# Attempts is a list and each user attempt is stored as a dictionary in this list
def deleteAttempt(attempts):
    print('\n')
    # Loops through dict in list and prints out userID,grade,time submitted for each attempt
    for i, userAttempt in enumerate(attempts):
        print(f'Attempt {i+1}: ' + userAttempt['UserID'] + '\tGrade: ' + '\33[32m' +userAttempt['Grade (%)'] + '\33[0m' + '\tTime Submitted: ' + userAttempt['Time Submitted'])

    deleteAttemptQuestion = f'\nEnter the index of the attempt to delete attempt [1 to {i+1}]\n[0] Cancel (Back)\n>>> '
    chosenOption = validationRange(start=0,end=i+1,question=deleteAttemptQuestion)

    # Double check if admin really wants to delete attempt
    if chosenOption != 0:
        checkOption = validationRange(start=0,end=1,question='\n' + '\33[41m' + '*** CONFIRMATION : Delete Attempt? ***' + '\33[0m' + '\n\n[1] Yes\t [0] No (Back)\n>>> ')

        # if admin confirms to delete user attempt, delete it from list and rewrite to csv files
        if checkOption == 1:
            del attempts[chosenOption-1]  # Deletes user attempt

            # Header of the csv file is contained within field list
            field = []
            for dictionary in attempts:
                for key in dictionary:
                    # Appends all keys that attempt 1 has if it exists in csv file
                    field.append(key)
                break

            with open(resultsCsv,'w') as fn: # write mode
                # Using dict writer as data is stored in dict
                writer = csv.DictWriter(fn,fieldnames = field)

                # Writing Headers (field names)
                writer.writeheader()
                
                # Writing of data rows
                writer.writerows(attempts)
            
            input('\33[42m' + '\nAttempt Deleted Successfully! Press enter to continue...' + '\33[0m' + '\n')

# This function will help to register and delete users
def userSetting():
    while True:
        # Creates a user dict by reading file userid_pswd.txt
        usersDict = readFile(userID_pwdTxt)

        if usersDict == {}:  # Checking for empty dictionary
            noUser = True
        else:
            noUser = False

        userSettingMenu = '\n---------------------------------------------\n' + '\33[32m' +  '\t      ' + '\33[4m' + '{ User Settings }' + '\33[0m'
        userSettingMenu += '\n\n[1] View User List\n[2] Register User\n[3] Delete User\n[4] Reset User Password\n[5] Delete User Attempt\n[0] Back'
        userSettingMenu += '\n\n---------------------------------------------\n>>> '

        chosenOption = validationRange(start=0,end=5,question=userSettingMenu)

        if chosenOption == 0:
            break

        # Viewing of current users in user list
        elif chosenOption == 1 and noUser == False:
            print('\n' + '\33[32m' + 'Current User List' + '\33[0m' + '\n')
            for key in usersDict:
                print('\33[32m' +key + ' : ' + '\33[0m' + usersDict[key][0])

        # Register Users
        elif chosenOption == 2:
            registerUser(dict = usersDict)

        # Deleting of User
        elif chosenOption == 3 and noUser == False:
            deleteUser(dict = usersDict)

        # Resetting of pwd of selected user
        elif chosenOption == 4 and noUser == False:
            resetPwd(dict = usersDict)

        elif noUser == True: 
           print('\n'  + '\33[41m' + 'Error! There are no Users in database!' + '\33[0m' + '\n')
        

        elif chosenOption == 5:

            # list that contains all previous attempts stored in csv file
            dataList = []
            # Reading of previously stored data in csv file and store in a list
            with open(resultsCsv,'r') as file: # Read mode
                writer = csv.DictReader(file)
                for line in writer:
                    # Appends each attempt into list as a dictionary
                    dataList.append(dict(line))

            if dataList != []: # Ensures that quiz_results.csv is not empty
                deleteAttempt(attempts = dataList)
            else:
                print('\n'  + '\33[41m' + 'Error! There are no attempts in quiz!' + '\33[0m' + '\n')

# This function generates a statistical report based on user's performance in the quiz under the quiz_result.csv
# This function takes in results as an argument. Results is a list that contains all user's attempt to quiz
# each user's attempt in the quiz is stored as a dictionary
def generateReport(results):
    numOfQuestionTested = []    

    # Appends number of question tested in quiz for the first attempt
    numOfQuestionTested.append(results[0]['Number of Question Tested'])

    # different number of questions tested and append in numOfQuestionTested List
    for attempt in results:
        if attempt['Number of Question Tested'] not in numOfQuestionTested:
            numOfQuestionTested.append(attempt['Number of Question Tested'])

    testStatistics = {}
    # Create a key based on the num of question tested and divide the attempts based off it
    for i in numOfQuestionTested:
        testStatistics[i] = []

    # For each attempt in results, if the number of question tested is equal
    # Append that attempt according to its key which is based of the number of questions tested
    # This is so that data isint skewed or altered due to different number of questions being tested
    for questionTested in numOfQuestionTested:
        for attempt in results:
            if questionTested == attempt['Number of Question Tested']:
                testStatistics[questionTested].append(attempt)

    reportMenu = '\n---------------------------------------------\n' + '\33[32m' +  '\t      ' + '\33[4m' + '{ Quiz Report }' + '\33[0m' + '\n'
    
    # Sorts list from ascending 
    numOfQuestionTested.sort()
    
    # Print for the different amounts of questions tested 
    for i in numOfQuestionTested:
        reportMenu += '\nNumber of Question Tested: ' + i
    
    reportMenu += '\n\n---------------------------------------------\n'
    reportMenu += '\nPlease Enter the Number of Question Tested to view its respective report\n[0] Cancel (back)\n>>> '

    # For quitting / going back
    numOfQuestionTested.append('0')
    
    chosenOption = listRangeValidation(list=numOfQuestionTested,question=reportMenu)

    # if user does not quit, then go and print a statistical report based on the number of questions tested
    if chosenOption != '0': 
        
        questionReport = '\n' + '\33[32m' + 'Statistics for all user inputs (options)' + '\33[0m'
        questionReport += '\n========================================================================================================================'
        questionReport += '\nQuestion\t\t\t\t\t|  Correct Option  |  Option A  |  Option B  |  Option C  |  Option D  |'
        questionReport += '\n========================================================================================================================'

        print(questionReport)
        questionDict = readFile(txtFile=questionPoolTxt)

        # for each question in question Pool, print the number of inputs for a) to d) based on all user inputs
        # To give a statistics on how many people choose which options
        for i, key in enumerate(questionDict):
            countA = 0
            countB = 0
            countC = 0
            countD = 0
            # checks through each attempt 
            for attempt in testStatistics[chosenOption]:
                keyList = []        # keylist to contain all keys of attempts
                for dictKey in attempt:
                    keyList.append(dictKey)                             # append the key onto keyList
                    if questionDict[key][0] == attempt[dictKey]:        # if question is found within attempt[key]
                        userAnswerIndex = keyList.index(dictKey) + 2    # the index of the user's answer is found key +2

                userAnswer = attempt[keyList[userAnswerIndex]]          # Store user answer
                
                # adds respective count for user inputs a to d
                if userAnswer == 'a)':
                    countA += 1
                
                elif userAnswer == 'b)':
                    countB += 1
                
                elif userAnswer == 'c)':
                    countC += 1
                
                elif userAnswer == 'd)':
                    countD += 1 

            questionLength = len(questionDict[key][0])
            
            # All of this is for spacing, formatting of strings
            if questionLength <= 10:
                noOfTimes = '\t\t\t\t\t'
            
            elif questionLength < 20:
                noOfTimes = '\t\t\t\t'
            
            elif questionLength < 30:
                noOfTimes = '\t\t\t'
            
            elif questionLength < 35: 
                noOfTimes = '\t\t'

            elif questionLength < 45:
                noOfTimes = '\t'
            
            else:
                noOfTimes = ''
            # Prints question, correct answer, and how many users input as options a to d
            print(f'{i+1}. {questionDict[key][0]}{noOfTimes}|        {questionDict[key][5]}        '+ f'|     {countA}      |     {countB}      |     {countC}      |     {countD}      |')
            print('------------------------------------------------------------------------------------------------------------------------')
        
        # press enter to continue for more stats
        input('\33[42m' + 'Press enter for more statistics...' + '\33[0m' + '\n')

        timeTakenList = []
        gradeList = []
        numOfQuestionAnswered = []
        numOfCorrectAnswer = []
        numUserAttempts = len(testStatistics[chosenOption])

        # Appends data to appropriate list to be used for calculation later
        # Since we need it to be used for calculations, we will have to change the datatype to int / float
        for attempt in testStatistics[chosenOption]:    
            # Append to timeTaken list
            timeTakenList.append(int(attempt['Time Used (min)']))

            # Append to gradeList
            gradeList.append(float(attempt['Grade (%)']))

            # Append to numOfQuestionAnswered list
            numOfQuestionAnswered.append(int(attempt['Number of Question Answered']))

            # Append to numOfCorrectAnswer list
            numOfCorrectAnswer.append(int(attempt['Number of Correct Answer']))

        # Formatting of statistic report printing
        statisticReport =  '\n' + '\33[32m' + 'Statistics Report' + '\33[0m' +'\n==============================================' 
        statisticReport += f'\nTotal Amount of Attempts: {numUserAttempts}'
        statisticReport += '\n\nAverage Grade : ' + '\33[32m' + f'{statistics.mean(gradeList):.2f} %' + '\33[0m' 
        statisticReport += '\nHighest Grade: \t' + '\33[32m' + f'{max(gradeList):.2f} %' + '\33[0m'
        statisticReport += '\nLowest Grade: \t' + '\33[32m' + f'{min(gradeList):.2f} %' + '\33[0m' 
        statisticReport += '\nMedian Grade : \t' + '\33[32m' + f'{statistics.median(gradeList):.2f} %' + '\33[0m' 
        statisticReport += '\nMode Grade : \t' + '\33[32m' + f'{statistics.median(gradeList):.2f} %' + '\33[0m' 
        
        # Error occurs when there is only 1 attempt / 1 data in the dataset
        # This is because standard deviation requires at least 2 sets of data
        try:
            statisticReport += '\nStandard Deviation : ' + '\33[32m' + f'{statistics.stdev(gradeList):.2f}' + '\33[0m' 
            
        # for when error occurs, add no string to it
        except statistics.StatisticsError:
            statisticReport += ''
        finally:
            statisticReport += f'\n\nAverage Number of Questions Answered: {statistics.mean(numOfQuestionAnswered):.2f} / {chosenOption}'
            statisticReport += f'\nAverage Number of Correct Answers: {statistics.mean(numOfCorrectAnswer):.2f} / {chosenOption}'
            statisticReport += f'\nAverage Time Taken: {statistics.mean(timeTakenList)} min'
            statisticReport += '\n\n==============================================\n' 

        print(statisticReport)

        input('\33[42m' + 'Press enter to continue...' + '\33[0m' + '\n')


# This function helps the user go into the selected function given what they want to do in the admin menu
def mainMenu():

    # Formatting of main menu prompt
    mainMenu = '\n==============================================\n' + '\33[32m' + '\t\t' + '\33[4m'+ '\ Admin Menu /' + '\33[0m'
    mainMenu += '\n\n[1] User Settings\n[2] Setup Question Pool\n[3] Quiz Settings\n[4] Generate Quiz Report\n[0] Quit'
    mainMenu += '\n\n==============================================\n>>> '

    while True:    
        try: 
            chosenOption = validationRange(start=0,end=4,question=mainMenu)
            
            # Quit
            if chosenOption == 0:
                print('\33[91m' + 'Terminating Programme...' + '\33[0m')
                print('\33[32m' + 'Programme Terminated' + '\33[0m' + '\n')
                break

            # User Settings
            elif chosenOption == 1:
                userSetting()
            
            # Setup Question Pool
            elif chosenOption == 2:
                setupQuestion()

            # Quiz Settings
            elif chosenOption == 3:
                quizSetting()
            
            # Generate Quiz Report
            else: 
                # list that contains all previous attempts stored in csv file
                dataList = []
                # Reading of previously stored data in csv file and store in a list
                with open(resultsCsv,'r') as file: # Read mode
                    writer = csv.DictReader(file)
                    for line in writer:
                        # Appends each attempt into list as a dictionary
                        dataList.append(dict(line))
                
                if dataList != []: # if dataList is not empty, go to generate report
                    generateReport(results = dataList)
                else:              # Error for when csv file is empty
                    print('\n'  + '\33[41m' + 'Error! No Attempt has been made for quiz!' + '\33[0m' + '\n')

        except EOFError:            # error for when user enters ctrl + z
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')
        except KeyboardInterrupt:   # Error for when user enters ctrl + c
            print('\n'  + '\33[41m' + 'Error! Illegal character entered' + '\33[0m' + '\n')
            
mainMenu()