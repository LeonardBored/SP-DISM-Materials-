xsteg is a gtk+ frontend to stegdetect.

This is a direct compilation of the UNIX sources to a Windows binary.
If you run this code on a UNIX-like operating system, you will
experience better performance and stability.

The windows gtk+ libraries are very experimental.

The manpages for stegdetect and stegbreak have been converted to
PDF.  Read the stegdetect.pdf and stegbreak.pdf documents for
further information on the tools.

A paper describing the detection framework can be found at

  http://www.citi.umich.edu/u/provos/papers/detecting.pdf

You can support development at

  http://www.outguess.org/